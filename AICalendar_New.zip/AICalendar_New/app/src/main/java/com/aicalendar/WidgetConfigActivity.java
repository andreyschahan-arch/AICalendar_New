package com.aicalendar;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

public class WidgetConfigActivity extends Activity {

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private View previewLayout;
    private SeekBar seekBarAlpha;
    private TextView txtAlphaLabel;
    private RadioGroup rgColors;

    private int selectedColorRGB = Color.parseColor("#121212");
    private int currentAlpha = 204;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(RESULT_CANCELED);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }

        setContentView(R.layout.activity_widget_config);

        previewLayout = findViewById(R.id.widget_preview);
        txtAlphaLabel = findViewById(R.id.txt_alpha_label);
        seekBarAlpha = findViewById(R.id.seekbar_alpha);
        rgColors = findViewById(R.id.rg_colors);
        Button btnSave = findViewById(R.id.btn_save_config);

        updatePreview();

        seekBarAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					currentAlpha = progress;
					int percent = (int) ((progress / 255.0f) * 100);
					txtAlphaLabel.setText("Прозрачность фона: " + percent + "%");
					updatePreview();
				}

				@Override public void onStartTrackingTouch(SeekBar seekBar) {}
				@Override public void onStopTrackingTouch(SeekBar seekBar) {}
			});

        rgColors.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(RadioGroup group, int checkedId) {
					if (checkedId == R.id.rb_graphite) {
						selectedColorRGB = Color.parseColor("#2A2A2A");
					} else if (checkedId == R.id.rb_blue) {
						selectedColorRGB = Color.parseColor("#1A233A");
					} else if (checkedId == R.id.rb_light) {
						selectedColorRGB = Color.parseColor("#E0E0E0");
					} else {
						selectedColorRGB = Color.parseColor("#121212");
					}
					updatePreview();
				}
			});

        btnSave.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					saveAndExit();
				}
			});
    }

    private void updatePreview() {
        int finalColor = Color.argb(
            currentAlpha, 
            Color.red(selectedColorRGB), 
            Color.green(selectedColorRGB), 
            Color.blue(selectedColorRGB)
        );
        if (previewLayout != null) {
            previewLayout.setBackgroundColor(finalColor);
        }
    }

    private void saveAndExit() {
        int finalColor = Color.argb(
            currentAlpha, 
            Color.red(selectedColorRGB), 
            Color.green(selectedColorRGB), 
            Color.blue(selectedColorRGB)
        );

        SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        prefs.edit().putInt("widget_bg_color_" + appWidgetId, finalColor).apply();

        ShiftWidgetProvider.updateAllWidgets(this);

        Intent resultValue = new Intent();
        resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        setResult(RESULT_OK, resultValue);
        finish();
    }
}

