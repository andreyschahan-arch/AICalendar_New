package com.aicalendar;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;

public class WidgetConfigActivity extends Activity {

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private SeekBar seekBarOpacity;
    private View previewContainer;
    private int selectedBaseColor = Color.parseColor("#24272E");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(RESULT_CANCELED);

        // Получаем layout настройки
        int layoutId = getResources().getIdentifier("activity_widget_config", "layout", getPackageName());
        if (layoutId != 0) {
            setContentView(layoutId);
        }

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(
				AppWidgetManager.EXTRA_APPWIDGET_ID,
				AppWidgetManager.INVALID_APPWIDGET_ID
            );
        }

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }

        // Поиск элементов по строковым именам (безопасный поиск, чтобы не падать при сборке)
        int seekId = getResources().getIdentifier("seekBarOpacity", "id", getPackageName());
        if (seekId == 0) seekId = getResources().getIdentifier("seek_bar_opacity", "id", getPackageName());
        if (seekId != 0) seekBarOpacity = findViewById(seekId);

        int prevId = getResources().getIdentifier("widget_preview", "id", getPackageName());
        if (prevId == 0) prevId = getResources().getIdentifier("preview_container", "id", getPackageName());
        if (prevId != 0) previewContainer = findViewById(prevId);

        if (seekBarOpacity != null) {
            seekBarOpacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
					@Override
					public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
						updatePreviewColor();
					}

					@Override
					public void onStartTrackingTouch(SeekBar seekBar) {}

					@Override
					public void onStopTrackingTouch(SeekBar seekBar) {}
				});
        }

        // Привязка кнопок цветов
        setupColorButtons();

        // Кнопка применить
        int btnApplyId = getResources().getIdentifier("btn_apply", "id", getPackageName());
        if (btnApplyId == 0) btnApplyId = getResources().getIdentifier("btnApply", "id", getPackageName());

        if (btnApplyId != 0) {
            Button btnApply = findViewById(btnApplyId);
            if (btnApply != null) {
                btnApply.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							saveWidgetSettings();
						}
					});
            }
        }

        updatePreviewColor();
    }

    private void setupColorButtons() {
        String[] colorBtnNames = new String[]{
			"btn_color_black", "btn_color_blue", "btn_color_purple", "btn_color_pink", "btn_color_green"
        };

        final int[] colors = new int[]{
			Color.parseColor("#24272E"),
			Color.parseColor("#1A73E8"),
			Color.parseColor("#7C4DFF"),
			Color.parseColor("#E91E63"),
			Color.parseColor("#00BFA5")
        };

        for (int i = 0; i < colorBtnNames.length; i++) {
            int resId = getResources().getIdentifier(colorBtnNames[i], "id", getPackageName());
            if (resId != 0) {
                View btn = findViewById(resId);
                if (btn != null) {
                    final int color = colors[i];
                    btn.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								selectedBaseColor = color;
								updatePreviewColor();
							}
						});
                }
            }
        }
    }

    private void updatePreviewColor() {
        int alpha = (seekBarOpacity != null) ? seekBarOpacity.getProgress() : 204;
        int colorWithoutAlpha = selectedBaseColor & 0x00FFFFFF;
        int finalColor = (alpha << 24) | colorWithoutAlpha;

        if (previewContainer != null) {
            int bgImgId = getResources().getIdentifier("widget_background_img", "id", getPackageName());
            if (bgImgId != 0) {
                ImageView bgImg = previewContainer.findViewById(bgImgId);
                if (bgImg != null) {
                    bgImg.setColorFilter(finalColor);
                }
            } else {
                previewContainer.setBackgroundColor(finalColor);
            }
        }
    }

    private void saveWidgetSettings() {
        int alpha = (seekBarOpacity != null) ? seekBarOpacity.getProgress() : 204;
        int colorWithoutAlpha = selectedBaseColor & 0x00FFFFFF;
        int finalColor = (alpha << 24) | colorWithoutAlpha;

        SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        prefs.edit().putInt("widget_bg_color_" + appWidgetId, finalColor).apply();

        ShiftWidgetProvider.updateAllWidgets(this);

        Intent resultValue = new Intent();
        resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        setResult(RESULT_OK, resultValue);
        finish();
    }
}

