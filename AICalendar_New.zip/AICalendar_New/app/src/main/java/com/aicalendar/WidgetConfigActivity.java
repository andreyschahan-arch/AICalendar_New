package com.aicalendar;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

public class WidgetConfigActivity extends Activity {

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private View previewWidget;
    private SeekBar seekBarAlpha;

    private View[] colorButtons;
	// Набор сочных базовых цветов для палитры
    private int[] colors = new int[]{
		Color.parseColor("#24272E"),   // 1. Тёмный классический
		Color.parseColor("#3B82F6"),   // 2. Ярко-синий
		Color.parseColor("#8B5CF6"),   // 3. Фиолетовый
		Color.parseColor("#EC4899"),   // 4. Розовый / Пурпурный
		Color.parseColor("#10B981")    // 5. Изумрудно-зеленый
    };
	

    private int baseColor = colors[0];
    private int selectedColorIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_widget_config);

        // 1. Получаем ID настраиваемого виджета
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        // 2. Элементы управления
        previewWidget = findViewById(R.id.preview_widget);
        seekBarAlpha = findViewById(R.id.seekbar_alpha);
        Button btnApply = findViewById(R.id.btn_apply);

        // 3. Массив кнопок-кружков
        colorButtons = new View[]{
			findViewById(R.id.color_btn_dark),
			findViewById(R.id.color_btn_graphite),
			findViewById(R.id.color_btn_blue),
			findViewById(R.id.color_btn_emerald),
			findViewById(R.id.color_btn_purple)
        };

        // Назначаем клики по кружкам
        for (int i = 0; i < colorButtons.length; i++) {
            final int index = i;
            if (colorButtons[i] != null) {
                colorButtons[i].setOnClickListener(v -> selectColor(index));
            }
        }

        // Ползунок прозрачности
        seekBarAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					updatePreviewColor();
				}

				@Override public void onStartTrackingTouch(SeekBar seekBar) {}
				@Override public void onStopTrackingTouch(SeekBar seekBar) {}
			});

        // Кнопка Применить
        btnApply.setOnClickListener(v -> saveAndExit());

        // Выбираем первый цвет по умолчанию
        selectColor(0);
    }

    // Выбор цвета из палитры и подсвечивание синей рамкой
	private void selectColor(int index) {
        selectedColorIndex = index;
        baseColor = colors[index];

        for (int i = 0; i < colorButtons.length; i++) {
            if (colorButtons[i] == null) continue;

            GradientDrawable drawable = new GradientDrawable();
            drawable.setShape(GradientDrawable.OVAL);
            drawable.setColor(colors[i]); // Устанавливаем сочный цвет из массива

            // Активный кружок выделяем обводкой
            if (i == index) {
                drawable.setStroke(8, Color.parseColor("#0A84FF"));
            }

            colorButtons[i].setBackground(drawable);
        }

        updatePreviewColor();
    }
	

    // Обновление превью с сохранением скругления углов
    private void updatePreview() {
		int alpha = seekBarOpacity.getProgress(); // 0..255
		int colorWithoutAlpha = selectedBaseColor & 0x00FFFFFF;
		int finalColor = (alpha << 24) | colorWithoutAlpha;

		// Находим ImageView фона превью и красим его
		ImageView bgImg = previewContainer.findViewById(R.id.widget_background_img);
		if (bgImg != null) {
        bgImg.setColorFilter(finalColor);
		}
			}
		

    // Сохранение и выход
    private void saveAndExit() {
        int alpha = seekBarAlpha.getProgress();
        int finalColor = Color.argb(alpha, Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor));

        SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        prefs.edit().putInt("widget_bg_color_" + appWidgetId, finalColor).apply();

        // Обновляем виджеты на рабочем столе
        ShiftWidgetProvider.updateAllWidgets(this);

        Intent resultValue = new Intent();
        resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        setResult(RESULT_OK, resultValue);
        finish();
    }
}

