package com.aicalendar;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.SeekBar;

public class WidgetConfigActivity extends Activity {

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private View previewWidget;
    private SeekBar seekBarAlpha;
    private RadioGroup colorGroup;

    private int baseColor = Color.rgb(24, 24, 24); // Базовый цвет (Тёмный)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_widget_config);

        // Получаем ID настраиваемого виджета
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        // Находим элементы управления
        previewWidget = findViewById(R.id.preview_widget);
        seekBarAlpha = findViewById(R.id.seekbar_alpha);
        colorGroup = findViewById(R.id.color_group);
        Button btnApply = findViewById(R.id.btn_apply);

        // Слушатель ползунка прозрачности
        seekBarAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
				@Override
				public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
					updatePreviewColor();
				}

				@Override public void onStartTrackingTouch(SeekBar seekBar) {}
				@Override public void onStopTrackingTouch(SeekBar seekBar) {}
			});

        // Слушатель выбора цвета
        colorGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radio_graphite) {
                baseColor = Color.rgb(44, 44, 46);
            } else if (checkedId == R.id.radio_blue) {
                baseColor = Color.rgb(20, 30, 48);
            } else {
                baseColor = Color.rgb(24, 24, 24);
            }
            updatePreviewColor();
        });

        // Кнопка Применить
        btnApply.setOnClickListener(v -> saveAndExit());

        updatePreviewColor();
    }

    // Обновляем цвет карточки превью "НА ЛЕТУ"
    private void updatePreviewColor() {
        int alpha = seekBarAlpha.getProgress();
        int finalColor = Color.argb(alpha, Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor));

        // Менять цвет будем прямо у фона с сохранением скругления углов!
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setCornerRadius(45); // ~22dp в пикселях
        drawable.setColor(finalColor);

        previewWidget.setBackground(drawable);
    }

    // Сохранение и обновление настоящего виджета
    private void saveAndExit() {
        int alpha = seekBarAlpha.getProgress();
        int finalColor = Color.argb(alpha, Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor));

        SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        prefs.edit().putInt("widget_bg_color_" + appWidgetId, finalColor).apply();

        // Обновляем сам виджет на рабочем столе
        ShiftWidgetProvider.updateAllWidgets(this);

        Intent resultValue = new Intent();
        resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        setResult(RESULT_OK, resultValue);
        finish();
    }
}

