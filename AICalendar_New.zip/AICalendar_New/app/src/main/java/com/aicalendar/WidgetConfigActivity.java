package com.aicalendar;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;

public class WidgetConfigActivity extends Activity {

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private SeekBar seekBarOpacity;
    private View previewContainer;
    private int selectedBaseColor = Color.parseColor("#24272E");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(RESULT_CANCELED);
        setContentView(R.layout.activity_widget_config);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(
				AppWidgetManager.EXTRA_APPWIDGET_ID,
				AppWidgetManager.INVALID_APPWIDGET_ID
            );
        }

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }

        seekBarOpacity = findViewById(R.id.seekBarOpacity);
        previewContainer = findViewById(R.id.widget_preview);

        if (seekBarOpacity != null) {
            seekBarOpacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
					@Override
					public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
						updatePreviewColor();
					}

					@Override
					public void onStartTrackingTouch(SeekBar seekBar) {}

					@Override
					public void onStopTrackingTouch(SeekBar seekBar) {}
				});
        }

        // Кнопки по вашим именам файлов
        int[] btnIds = new int[]{
			R.id.btn_color_dark,
			R.id.btn_color_graphite,
			R.id.btn_color_blue,
			R.id.btn_color_purple,
			R.id.btn_color_emerald
        };

        final int[] colors = new int[]{
			Color.parseColor("#121212"),
			Color.parseColor("#24272E"),
			Color.parseColor("#1A73E8"),
			Color.parseColor("#7C4DFF"),
			Color.parseColor("#00BFA5")
        };

        for (int i = 0; i < btnIds.length; i++) {
            View btn = findViewById(btnIds[i]);
            if (btn != null) {
                final int color = colors[i];
                btn.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							selectedBaseColor = color;
							updatePreviewColor();
						}
					});
            }
        }

        Button btnApply = findViewById(R.id.btn_apply);
        if (btnApply != null) {
            btnApply.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						saveWidgetSettings();
					}
				});
        }

        updatePreviewColor();
    }

    private void updatePreviewColor() {
        int alpha = (seekBarOpacity != null) ? seekBarOpacity.getProgress() : 204;
        int colorWithoutAlpha = selectedBaseColor & 0x00FFFFFF;
        int finalColor = (alpha << 24) | colorWithoutAlpha;

        if (previewContainer != null) {
            ImageView bgImg = previewContainer.findViewById(R.id.widget_background_img);
            if (bgImg != null) {
                bgImg.setColorFilter(finalColor);
            }
        }
    }

    private void saveWidgetSettings() {
        int alpha = (seekBarOpacity != null) ? seekBarOpacity.getProgress() : 204;
        int colorWithoutAlpha = selectedBaseColor & 0x00FFFFFF;
        int finalColor = (alpha << 24) | colorWithoutAlpha;

        SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        prefs.edit().putInt("widget_bg_color_" + appWidgetId, finalColor).apply();

        ShiftWidgetProvider.updateAllWidgets(this);

        Intent resultValue = new Intent();
        resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        setResult(RESULT_OK, resultValue);
        finish();
    }
}

