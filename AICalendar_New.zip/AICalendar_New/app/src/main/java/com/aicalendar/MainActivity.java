package com.aicalendar;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Связываем с имеющимся layout activity_main
        int layoutId = getResources().getIdentifier("activity_main", "layout", getPackageName());
        if (layoutId != 0) {
            setContentView(layoutId);
        }

        prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);

        // Инициализация кнопки профилей
        int btnId = getResources().getIdentifier("btn_profiles", "id", getPackageName());
        if (btnId != 0) {
            View btnProfiles = findViewById(btnId);
            if (btnProfiles != null) {
                btnProfiles.setOnClickListener(v -> openProfileDialog(0));
            }
        }

        recalculateAndScheduleAlarms(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        recalculateAndScheduleAlarms(this);
    }

    // --- МЕТОДЫ, КОТОРЫЕ ВЫЗЫВАЕТ ProfileDialog ---

    public void openProfileDialog(int profileIndex) {
        ProfileDialog dialog = new ProfileDialog(this);
        dialog.show(this, profileIndex);
    }

    public String getProfileName(int index) {
        return prefs.getString("profile_name_" + index, "Смена " + (index + 1));
    }

    public int getProfilePeriod(int index) {
        return prefs.getInt("profile_period_" + index, 4);
    }

    public int getProfileColor(int index) {
        return prefs.getInt("profile_color_" + index, Color.parseColor("#4CAF50"));
    }

    public void fillAlarmRows(int profileIndex, LinearLayout container, ArrayList<EditText> times, ArrayList<EditText> tasks) {
        container.removeAllViews();
        times.clear();
        tasks.clear();
        addAlarmRowExternal(container, times, tasks, "06:00", "Смена");
    }

    public void addAlarmRowExternal(LinearLayout container, ArrayList<EditText> times, ArrayList<EditText> tasks, String time, String task) {
        EditText etTime = new EditText(this);
        etTime.setText(time);
        times.add(etTime);

        EditText etTask = new EditText(this);
        etTask.setText(task);
        tasks.add(etTask);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(etTime);
        row.addView(etTask);

        container.addView(row);
    }

    public void deleteProfileExternal(int index) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove("profile_name_" + index);
        editor.remove("profile_period_" + index);
        editor.remove("profile_color_" + index);
        editor.apply();

        recalculateAndScheduleAlarms(this);
    }

    public void saveProfileExternal(int index, String name, int period, int color, ArrayList<EditText> times, ArrayList<EditText> tasks) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("profile_name_" + index, name);
        editor.putInt("profile_period_" + index, period);
        editor.putInt("profile_color_" + index, color);
        editor.apply();

        recalculateAndScheduleAlarms(this);
    }

    // --- СИНХРОНИЗАЦИЯ И РАСЧЕТ ДЛЯ ВИДЖЕТА ---

    public static void recalculateAndScheduleAlarms(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("app_prefs", MODE_PRIVATE);

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1); // Старт со вчера

        String todayShiftName = prefs.getString("profile_name_0", "Выходной");

        for (int i = 0; i < 3; i++) {
            int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
            int color = prefs.getInt("profile_color_0", Color.TRANSPARENT);

            prefs.edit()
				.putString("widget_day_text_" + i, String.valueOf(dayOfMonth))
				.putInt("widget_color_" + i, color)
				.apply();

            cal.add(Calendar.DAY_OF_YEAR, 1);
        }

        prefs.edit().putString("widget_today_shift_name", todayShiftName).apply();

        // Обновляем виджет
        ShiftWidgetProvider.updateAllWidgets(context);
    }
}

