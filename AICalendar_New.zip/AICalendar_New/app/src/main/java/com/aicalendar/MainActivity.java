package com.aicalendar;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("AiCalendarPrefs", MODE_PRIVATE);

        // Безопасное создание UI
        createFallbackUI();

        // Вызываем перерасчет в защищенном блоке
        try {
            recalculateAndScheduleAlarms(this);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    private void createFallbackUI() {
        ScrollView scrollView = new ScrollView(this);
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(40, 40, 40, 40);
        mainLayout.setBackgroundColor(0xFF121212);

        TextView title = new TextView(this);
        title.setText("Календарь-Будильник");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 20, 0, 40);
        mainLayout.addView(title);

        Button btnProfiles = new Button(this);
        btnProfiles.setText("Управление типами дней");
        btnProfiles.setTextColor(Color.WHITE);
        btnProfiles.setBackgroundColor(0xFF222222);
        btnProfiles.setPadding(20, 30, 20, 30);
        btnProfiles.setOnClickListener(v -> openProfileDialog(0));
        mainLayout.addView(btnProfiles);

        scrollView.addView(mainLayout);
        setContentView(scrollView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            recalculateAndScheduleAlarms(this);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    // --- МЕТОДЫ ДЛЯ ProfileDialog ---

    public void openProfileDialog(int profileIndex) {
        try {
            ProfileDialog.show(this, profileIndex);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getProfileName(int index) {
        return prefs.getString("profile_name_" + index, "Смена " + (index + 1));
    }

    public int getProfilePeriod(int index) {
        return prefs.getInt("profile_period_" + index, 4);
    }

    public int getProfileColor(int index) {
        return prefs.getInt("profile_color_" + index, Color.parseColor("#4CAF50"));
    }

    public void fillAlarmRows(int profileIndex, LinearLayout container, ArrayList<EditText> times, ArrayList<EditText> tasks) {
        if (container == null) return;
        container.removeAllViews();
        if (times != null) times.clear();
        if (tasks != null) tasks.clear();

        String timeKey = "profile_alarm_time_" + profileIndex;
        String taskKey = "profile_alarm_task_" + profileIndex;
        String savedTime = prefs.getString(timeKey, "06:00");
        String savedTask = prefs.getString(taskKey, "");

        addAlarmRowExternal(container, times, tasks, savedTime, savedTask);
    }

    public void addAlarmRowExternal(LinearLayout container, ArrayList<EditText> times, ArrayList<EditText> tasks, String time, String task) {
        if (container == null) return;

        EditText etTime = new EditText(this);
        etTime.setText(time);
        etTime.setTextColor(Color.WHITE);
        if (times != null) times.add(etTime);

        EditText etTask = new EditText(this);
        etTask.setText(task);
        etTask.setTextColor(Color.WHITE);
        if (tasks != null) tasks.add(etTask);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(etTime);
        row.addView(etTask);

        container.addView(row);
    }

    public void deleteProfileExternal(int index) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove("profile_name_" + index);
        editor.remove("profile_period_" + index);
        editor.remove("profile_color_" + index);
        editor.remove("profile_alarm_time_" + index);
        editor.remove("profile_alarm_task_" + index);
        editor.apply();

        recalculateAndScheduleAlarms(this);
    }

    public void saveProfileExternal(int index, String name, int period, int color, ArrayList<EditText> times, ArrayList<EditText> tasks) {
        SharedPreferences.Editor editor = prefs.edit();

        int targetIndex = index;
        if (targetIndex == -1) {
            targetIndex = prefs.getInt("profiles_count", 0);
            editor.putInt("profiles_count", targetIndex + 1);
        }

        editor.putString("profile_name_" + targetIndex, name);
        editor.putInt("profile_period_" + targetIndex, period);
        editor.putInt("profile_color_" + targetIndex, color);

        if (times != null && !times.isEmpty() && tasks != null && !tasks.isEmpty()) {
            editor.putString("profile_alarm_time_" + targetIndex, times.get(0).getText().toString());
            editor.putString("profile_alarm_task_" + targetIndex, tasks.get(0).getText().toString());
        }

        editor.apply();

        recalculateAndScheduleAlarms(this);
    }

    // --- ОБНОВЛЕНИЕ И СИНХРОНИЗАЦИЯ ВИДЖЕТА ---

    public static void recalculateAndScheduleAlarms(Context context) {
        if (context == null) return;

        try {
            SharedPreferences prefs = context.getSharedPreferences("AiCalendarPrefs", Context.MODE_PRIVATE);

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, -1);

            String todayShiftName = prefs.getString("profile_name_0", "Выходной");

            SharedPreferences.Editor editor = prefs.edit();
            for (int i = 0; i < 3; i++) {
                int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
                int color = prefs.getInt("profile_color_0", Color.TRANSPARENT);

                editor.putString("widget_day_text_" + i, String.valueOf(dayOfMonth));
                editor.putInt("widget_color_" + i, color);

                cal.add(Calendar.DAY_OF_YEAR, 1);
            }

            editor.putString("widget_today_shift_name", todayShiftName);
            editor.apply();

            ShiftWidgetProvider.updateAllWidgets(context);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

