package com.aicalendar;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {

    private SharedPreferences prefs;
    private Calendar currentCalendar;
    private LinearLayout mainLayout;
    private TextView tvMonthYear;
    private GridLayout gridCalendar;
    private LinearLayout profilesContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("AiCalendarPrefs", MODE_PRIVATE);
        currentCalendar = Calendar.getInstance();

        // Полный динамический UI с сеткой календаря
        buildMainUI();

        // Перерасчет и синхронизация
        recalculateAndScheduleAlarms(this);
    }

    private void buildMainUI() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new ViewGroup.LayoutParams(
									   ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        scrollView.setBackgroundColor(0xFF121212);

        mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(30, 40, 30, 40);

        // --- 1. ШАПКА КАЛЕНДАРЯ (Переключение месяцев) ---
        LinearLayout monthHeader = new LinearLayout(this);
        monthHeader.setOrientation(LinearLayout.HORIZONTAL);
        monthHeader.setGravity(Gravity.CENTER_VERTICAL);
        monthHeader.setPadding(0, 10, 0, 30);

        Button btnPrev = new Button(this);
        btnPrev.setText("◄");
        btnPrev.setTextColor(Color.WHITE);
        btnPrev.setBackgroundColor(0xFF222222);
        btnPrev.setOnClickListener(v -> {
            currentCalendar.add(Calendar.MONTH, -1);
            updateCalendarGrid();
        });

        tvMonthYear = new TextView(this);
        tvMonthYear.setTextColor(Color.WHITE);
        tvMonthYear.setTextSize(20);
        tvMonthYear.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        tvMonthYear.setLayoutParams(titleParams);

        Button btnNext = new Button(this);
        btnNext.setText("►");
        btnNext.setTextColor(Color.WHITE);
        btnNext.setBackgroundColor(0xFF222222);
        btnNext.setOnClickListener(v -> {
            currentCalendar.add(Calendar.MONTH, 1);
            updateCalendarGrid();
        });

        monthHeader.addView(btnPrev);
        monthHeader.addView(tvMonthYear);
        monthHeader.addView(btnNext);
        mainLayout.addView(monthHeader);

        // --- 2. ДНИ НЕДЕЛИ ---
        LinearLayout daysHeader = new LinearLayout(this);
        daysHeader.setOrientation(LinearLayout.HORIZONTAL);
        String[] daysOfWeek = {"Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"};
        for (String day : daysOfWeek) {
            TextView tvDay = new TextView(this);
            tvDay.setText(day);
            tvDay.setTextColor(Color.GRAY);
            tvDay.setGravity(Gravity.CENTER);
            tvDay.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));
            daysHeader.addView(tvDay);
        }
        mainLayout.addView(daysHeader);

        // --- 3. СЕТКА ДНЕЙ (7 колонок) ---
        gridCalendar = new GridLayout(this);
        gridCalendar.setColumnCount(7);
        gridCalendar.setPadding(0, 20, 0, 40);
        mainLayout.addView(gridCalendar);

        // --- 4. РАЗДЕЛИТЕЛЬ ---
        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 2));
        divider.setBackgroundColor(0xFF444444);
        mainLayout.addView(divider);

        // --- 5. УПРАВЛЕНИЕ ТИПАМИ ДНЕЙ (ПРОФИЛИ) ---
        TextView profilesTitle = new TextView(this);
        profilesTitle.setText("Типы дней / Смены:");
        profilesTitle.setTextColor(Color.WHITE);
        profilesTitle.setTextSize(18);
        profilesTitle.setPadding(0, 30, 0, 20);
        mainLayout.addView(profilesTitle);

        profilesContainer = new LinearLayout(this);
        profilesContainer.setOrientation(LinearLayout.VERTICAL);
        mainLayout.addView(profilesContainer);

        Button btnAddProfile = new Button(this);
        btnAddProfile.setText("+ Добавить новый тип дня");
        btnAddProfile.setTextColor(Color.GREEN);
        btnAddProfile.setBackgroundColor(0xFF222222);
        btnAddProfile.setPadding(20, 20, 20, 20);
        btnAddProfile.setOnClickListener(v -> openProfileDialog(-1));
        mainLayout.addView(btnAddProfile);

        scrollView.addView(mainLayout);
        setContentView(scrollView);

        // Отрисовка
        updateCalendarGrid();
        renderProfilesList();
    }

    // --- ОБНОВЛЕНИЕ СЕТКИ КАЛЕНДАРЯ ---
    private void updateCalendarGrid() {
        if (gridCalendar == null) return;
        gridCalendar.removeAllViews();

        SimpleDateFormat monthFormat = new SimpleDateFormat("LLLL yyyy", new Locale("ru"));
        String monthName = monthFormat.format(currentCalendar.getTime());
        tvMonthYear.setText(monthName.substring(0, 1).toUpperCase() + monthName.substring(1));

        Calendar cal = (Calendar) currentCalendar.clone();
        cal.set(Calendar.DAY_OF_MONTH, 1);

        int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 2;
        if (firstDayOfWeek < 0) firstDayOfWeek = 6; // Вс -> 6

        int maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

        // Пустые ячейки в начале месяца
        for (int i = 0; i < firstDayOfWeek; i++) {
            TextView emptyView = new TextView(this);
            gridCalendar.addView(emptyView);
        }

        // Заполнение дней
        Calendar today = Calendar.getInstance();
        for (int day = 1; day <= maxDays; day++) {
            TextView dayView = new TextView(this);
            dayView.setText(String.valueOf(day));
            dayView.setTextColor(Color.WHITE);
            dayView.setGravity(Gravity.CENTER);
            dayView.setPadding(20, 20, 20, 20);

            // Выделение сегодняшнего дня
            if (cal.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                cal.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)) {
                dayView.setBackgroundColor(0xFF333366);
            }

            gridCalendar.addView(dayView);
            cal.add(Calendar.DAY_OF_MONTH, 1);
        }
    }

    // --- ОТОБРАЖЕНИЕ СПИСКА ПРОФИЛЕЙ ---
    private void renderProfilesList() {
        if (profilesContainer == null) return;
        profilesContainer.removeAllViews();

        int count = prefs.getInt("profiles_count", 1);
        if (count == 0) count = 1;

        for (int i = 0; i < count; i++) {
            final int index = i;
            String name = getProfileName(i);
            int color = getProfileColor(i);

            Button btnProfile = new Button(this);
            btnProfile.setText(name);
            btnProfile.setTextColor(Color.WHITE);
            btnProfile.setBackgroundColor(color != Color.TRANSPARENT ? color : 0xFF333333);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
				ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.setMargins(0, 5, 0, 15);
            btnProfile.setLayoutParams(params);

            btnProfile.setOnClickListener(v -> openProfileDialog(index));
            profilesContainer.addView(btnProfile);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            updateCalendarGrid();
            renderProfilesList();
            recalculateAndScheduleAlarms(this);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    // --- МЕТОДЫ ДЛЯ ProfileDialog ---

    public void openProfileDialog(int profileIndex) {
        try {
            ProfileDialog.show(this, profileIndex);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getProfileName(int index) {
        return prefs.getString("profile_name_" + index, "Смена " + (index + 1));
    }

    public int getProfilePeriod(int index) {
        return prefs.getInt("profile_period_" + index, 4);
    }

    public int getProfileColor(int index) {
        return prefs.getInt("profile_color_" + index, Color.parseColor("#4CAF50"));
    }

    public void fillAlarmRows(int profileIndex, LinearLayout container, ArrayList<EditText> times, ArrayList<EditText> tasks) {
        if (container == null) return;
        container.removeAllViews();
        if (times != null) times.clear();
        if (tasks != null) tasks.clear();

        String timeKey = "profile_alarm_time_" + profileIndex;
        String taskKey = "profile_alarm_task_" + profileIndex;
        String savedTime = prefs.getString(timeKey, "06:00");
        String savedTask = prefs.getString(taskKey, "");

        addAlarmRowExternal(container, times, tasks, savedTime, savedTask);
    }

    public void addAlarmRowExternal(LinearLayout container, ArrayList<EditText> times, ArrayList<EditText> tasks, String time, String task) {
        if (container == null) return;

        EditText etTime = new EditText(this);
        etTime.setText(time);
        etTime.setTextColor(Color.WHITE);
        if (times != null) times.add(etTime);

        EditText etTask = new EditText(this);
        etTask.setText(task);
        etTask.setTextColor(Color.WHITE);
        if (tasks != null) tasks.add(etTask);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(etTime);
        row.addView(etTask);

        container.addView(row);
    }

    public void deleteProfileExternal(int index) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove("profile_name_" + index);
        editor.remove("profile_period_" + index);
        editor.remove("profile_color_" + index);
        editor.remove("profile_alarm_time_" + index);
        editor.remove("profile_alarm_task_" + index);

        int count = prefs.getInt("profiles_count", 1);
        if (count > 1) {
            editor.putInt("profiles_count", count - 1);
        }
        editor.apply();

        renderProfilesList();
        recalculateAndScheduleAlarms(this);
    }

    public void saveProfileExternal(int index, String name, int period, int color, ArrayList<EditText> times, ArrayList<EditText> tasks) {
        SharedPreferences.Editor editor = prefs.edit();

        int targetIndex = index;
        if (targetIndex == -1) {
            targetIndex = prefs.getInt("profiles_count", 0);
            editor.putInt("profiles_count", targetIndex + 1);
        }

        editor.putString("profile_name_" + targetIndex, name);
        editor.putInt("profile_period_" + targetIndex, period);
        editor.putInt("profile_color_" + targetIndex, color);

        if (times != null && !times.isEmpty() && tasks != null && !tasks.isEmpty()) {
            editor.putString("profile_alarm_time_" + targetIndex, times.get(0).getText().toString());
            editor.putString("profile_alarm_task_" + targetIndex, tasks.get(0).getText().toString());
        }

        editor.apply();

        renderProfilesList();
        recalculateAndScheduleAlarms(this);
    }

    // --- ОБНОВЛЕНИЕ И СИНХРОНИЗАЦИЯ ВИДЖЕТА ---

    public static void recalculateAndScheduleAlarms(Context context) {
        if (context == null) return;

        try {
            SharedPreferences prefs = context.getSharedPreferences("AiCalendarPrefs", Context.MODE_PRIVATE);

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, -1);

            String todayShiftName = prefs.getString("profile_name_0", "Выходной");

            SharedPreferences.Editor editor = prefs.edit();
            for (int i = 0; i < 3; i++) {
                int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
                int color = prefs.getInt("profile_color_0", Color.TRANSPARENT);

                editor.putString("widget_day_text_" + i, String.valueOf(dayOfMonth));
                editor.putInt("widget_color_" + i, color);

                cal.add(Calendar.DAY_OF_YEAR, 1);
            }

            editor.putString("widget_today_shift_name", todayShiftName);
            editor.apply();

            ShiftWidgetProvider.updateAllWidgets(context);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

