package com.aicalendar;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Используем точное имя файла настроек из ProfileDialog.java
        prefs = getSharedPreferences("AiCalendarPrefs", MODE_PRIVATE);

        int layoutId = getResources().getIdentifier("activity_main", "layout", getPackageName());
        if (layoutId == 0) {
            layoutId = getResources().getIdentifier("main_activity", "layout", getPackageName());
        }
        if (layoutId != 0) {
            setContentView(layoutId);
        }

        int btnId = getResources().getIdentifier("btn_profiles", "id", getPackageName());
        if (btnId != 0) {
            View btnProfiles = findViewById(btnId);
            if (btnProfiles != null) {
                btnProfiles.setOnClickListener(v -> openProfileDialog(0));
            }
        }

        try {
            recalculateAndScheduleAlarms(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            recalculateAndScheduleAlarms(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // --- МЕТОДЫ, ВЫЗЫВАЕМЫЕ ИЗ ProfileDialog ---

    public void openProfileDialog(int profileIndex) {
        // Вызов статического метода show из ProfileDialog
        ProfileDialog.show(this, profileIndex);
    }

    public String getProfileName(int index) {
        return prefs.getString("profile_name_" + index, "Смена " + (index + 1));
    }

    public int getProfilePeriod(int index) {
        return prefs.getInt("profile_period_" + index, 4);
    }

    public int getProfileColor(int index) {
        return prefs.getInt("profile_color_" + index, Color.parseColor("#4CAF50"));
    }

    public void fillAlarmRows(int profileIndex, LinearLayout container, ArrayList<EditText> times, ArrayList<EditText> tasks) {
        if (container == null) return;
        container.removeAllViews();
        if (times != null) times.clear();
        if (tasks != null) tasks.clear();

        // Загрузка сохранившихся напоминаний для профиля
        String timeKey = "profile_alarm_time_" + profileIndex;
        String taskKey = "profile_alarm_task_" + profileIndex;
        String savedTime = prefs.getString(timeKey, "06:00");
        String savedTask = prefs.getString(taskKey, "");

        addAlarmRowExternal(container, times, tasks, savedTime, savedTask);
    }

    public void addAlarmRowExternal(LinearLayout container, ArrayList<EditText> times, ArrayList<EditText> tasks, String time, String task) {
        if (container == null) return;

        EditText etTime = new EditText(this);
        etTime.setText(time);
        etTime.setTextColor(Color.WHITE);
        if (times != null) times.add(etTime);

        EditText etTask = new EditText(this);
        etTask.setText(task);
        etTask.setTextColor(Color.WHITE);
        if (tasks != null) tasks.add(etTask);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(etTime);
        row.addView(etTask);

        container.addView(row);
    }

    public void deleteProfileExternal(int index) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove("profile_name_" + index);
        editor.remove("profile_period_" + index);
        editor.remove("profile_color_" + index);
        editor.remove("profile_alarm_time_" + index);
        editor.remove("profile_alarm_task_" + index);
        editor.apply();

        recalculateAndScheduleAlarms(this);
    }

    public void saveProfileExternal(int index, String name, int period, int color, ArrayList<EditText> times, ArrayList<EditText> tasks) {
        SharedPreferences.Editor editor = prefs.edit();

        // Если клонируем/создаем новый (индекс -1), генерируем следующий доступный индекс
        int targetIndex = index;
        if (targetIndex == -1) {
            targetIndex = prefs.getInt("profiles_count", 0);
            editor.putInt("profiles_count", targetIndex + 1);
        }

        editor.putString("profile_name_" + targetIndex, name);
        editor.putInt("profile_period_" + targetIndex, period);
        editor.putInt("profile_color_" + targetIndex, color);

        if (times != null && !times.isEmpty() && tasks != null && !tasks.isEmpty()) {
            editor.putString("profile_alarm_time_" + targetIndex, times.get(0).getText().toString());
            editor.putString("profile_alarm_task_" + targetIndex, tasks.get(0).getText().toString());
        }

        editor.apply();

        recalculateAndScheduleAlarms(this);
    }

    // --- ОБНОВЛЕНИЕ И СИНХРОНИЗАЦИЯ ВИДЖЕТА ---

    public static void recalculateAndScheduleAlarms(Context context) {
        if (context == null) return;

        SharedPreferences prefs = context.getSharedPreferences("AiCalendarPrefs", Context.MODE_PRIVATE);

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1);

        String todayShiftName = prefs.getString("profile_name_0", "Выходной");

        for (int i = 0; i < 3; i++) {
            int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
            int color = prefs.getInt("profile_color_0", Color.TRANSPARENT);

            prefs.edit()
				.putString("widget_day_text_" + i, String.valueOf(dayOfMonth))
				.putInt("widget_color_" + i, color)
				.apply();

            cal.add(Calendar.DAY_OF_YEAR, 1);
        }

        prefs.edit().putString("widget_today_shift_name", todayShiftName).apply();

        try {
            ShiftWidgetProvider.updateAllWidgets(context);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

