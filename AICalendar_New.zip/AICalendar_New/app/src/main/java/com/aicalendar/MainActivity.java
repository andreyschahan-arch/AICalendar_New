package com.aicalendar;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            // Прямое связывание с макетом
            setContentView(R.layout.activity_main);
        } catch (Exception e) {
            e.printStackTrace();
        }

        prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);

        try {
            View btnProfiles = findViewById(R.id.btn_profiles);
            if (btnProfiles != null) {
                btnProfiles.setOnClickListener(v -> openProfileDialog(0));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            recalculateAndScheduleAlarms(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            recalculateAndScheduleAlarms(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // --- МЕТОДЫ ДЛЯ ProfileDialog ---

    public void openProfileDialog(int profileIndex) {
        try {
            ProfileDialog dialog = new ProfileDialog();
            dialog.show(this, profileIndex);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getProfileName(int index) {
        return prefs.getString("profile_name_" + index, "Смена " + (index + 1));
    }

    public int getProfilePeriod(int index) {
        return prefs.getInt("profile_period_" + index, 4);
    }

    public int getProfileColor(int index) {
        return prefs.getInt("profile_color_" + index, Color.parseColor("#4CAF50"));
    }

    public void fillAlarmRows(int profileIndex, LinearLayout container, ArrayList<EditText> times, ArrayList<EditText> tasks) {
        if (container == null) return;
        container.removeAllViews();
        if (times != null) times.clear();
        if (tasks != null) tasks.clear();
        addAlarmRowExternal(container, times, tasks, "06:00", "Смена");
    }

    public void addAlarmRowExternal(LinearLayout container, ArrayList<EditText> times, ArrayList<EditText> tasks, String time, String task) {
        if (container == null) return;

        EditText etTime = new EditText(this);
        etTime.setText(time);
        if (times != null) times.add(etTime);

        EditText etTask = new EditText(this);
        etTask.setText(task);
        if (tasks != null) tasks.add(etTask);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(etTime);
        row.addView(etTask);

        container.addView(row);
    }

    public void deleteProfileExternal(int index) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove("profile_name_" + index);
        editor.remove("profile_period_" + index);
        editor.remove("profile_color_" + index);
        editor.apply();

        recalculateAndScheduleAlarms(this);
    }

    public void saveProfileExternal(int index, String name, int period, int color, ArrayList<EditText> times, ArrayList<EditText> tasks) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("profile_name_" + index, name);
        editor.putInt("profile_period_" + index, period);
        editor.putInt("profile_color_" + index, color);
        editor.apply();

        recalculateAndScheduleAlarms(this);
    }

    // --- СИНХРОНИЗАЦИЯ С ВИДЖЕТОМ ---

    public static void recalculateAndScheduleAlarms(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getSharedPreferences("app_prefs", MODE_PRIVATE);

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1);

        String todayShiftName = prefs.getString("profile_name_0", "Выходной");

        for (int i = 0; i < 3; i++) {
            int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
            int color = prefs.getInt("profile_color_0", Color.TRANSPARENT);

            prefs.edit()
				.putString("widget_day_text_" + i, String.valueOf(dayOfMonth))
				.putInt("widget_color_" + i, color)
				.apply();

            cal.add(Calendar.DAY_OF_YEAR, 1);
        }

        prefs.edit().putString("widget_today_shift_name", todayShiftName).apply();

        try {
            ShiftWidgetProvider.updateAllWidgets(context);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

