package com.aicalendar;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Используем единое имя хранилища настроек "app_prefs"
        prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);

        // Кнопка настройки профилей смен (если есть)
        View btnProfiles = findViewById(R.id.btn_profiles);
        if (btnProfiles != null) {
            btnProfiles.setOnClickListener(v -> openProfileDialog());
        }

        // Выполняем первичный расчет и обновление виджета при запуске
        recalculateAndScheduleAlarms(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // При каждом возврате в приложение перерассчитываем данные и обновляем виджет
        recalculateAndScheduleAlarms(this);
    }

    /**
     * Открытие диалога редактирования профилей смен
     */
    private void openProfileDialog() {
        ProfileDialog dialog = new ProfileDialog(this, new ProfileDialog.OnProfilesSavedListener() {
				@Override
				public void onProfilesSaved() {
					// После сохранения профилей сразу обновляем календарь и виджет
					recalculateAndScheduleAlarms(MainActivity.this);
				}
			});
        dialog.show();
    }

    /**
     * Полный метод синхронизации: рассчитывает смены на Вчера, Сегодня, Завтра
     * и сразу отправляет команду обновлять виджет.
     */
    public static void recalculateAndScheduleAlarms(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("app_prefs", MODE_PRIVATE);

        // 1. Считываем сохраненный JSON с профилями смен
        String profilesJson = prefs.getString("day_profiles_json", "[]");
        List<DayProfile> profiles = ProfileDialog.parseProfilesFromJson(profilesJson);

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1); // Начинаем расчет со вчерашнего дня (-1)

        String todayShiftName = "Выходной";

        // 2. Проходим 3 дня: 0 = Вчера, 1 = Сегодня, 2 = Завтра
        for (int i = 0; i < 3; i++) {
            long currentMillis = cal.getTimeInMillis();
            int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);

            String shiftNameForDay = "";
            int colorForDay = Color.TRANSPARENT;

            // Ищем совпадение по активным профилям смен
            if (profiles != null) {
                for (DayProfile profile : profiles) {
                    if (profile.isActive() && profile.matchesDate(currentMillis)) {
                        shiftNameForDay = profile.getName();
                        colorForDay = profile.getColor();
                        break;
                    }
                }
            }

            // Индекс 1 отвечает за текущий день ("Сегодня")
            if (i == 1) {
                todayShiftName = shiftNameForDay.isEmpty() ? "Выходной" : shiftNameForDay;
            }

            // Записываем данные для 3-х ячеек виджета
            prefs.edit()
				.putString("widget_day_text_" + i, String.valueOf(dayOfMonth))
				.putInt("widget_color_" + i, colorForDay)
				.apply();

            cal.add(Calendar.DAY_OF_YEAR, 1);
        }

        // Сохраняем имя смены на сегодня
        prefs.edit().putString("widget_today_shift_name", todayShiftName).apply();

        // 3. Отправляем сигнал виджету обновиться
        ShiftWidgetProvider.updateAllWidgets(context);
    }
}

