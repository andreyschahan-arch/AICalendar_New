package com.aicalendar;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.widget.RemoteViews;

public class ShiftWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    public static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);

        // Получаем и применяем цвет фона
        SharedPreferences prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        int defaultColor = Color.parseColor("#CC24272E");
        int bgColor = prefs.getInt("widget_bg_color_" + appWidgetId, defaultColor);

        views.setInt(R.id.widget_background_img, "setColorFilter", bgColor);

        // Настройка фона для плашек дней
        views.setInt(R.id.day_m2, "setBackgroundResource", R.drawable.bg_day_card);
        views.setInt(R.id.day_m1, "setBackgroundResource", R.drawable.bg_day_card);
        views.setInt(R.id.day_today, "setBackgroundResource", R.drawable.today_bg);
        views.setInt(R.id.day_p1, "setBackgroundResource", R.drawable.bg_day_card);
        views.setInt(R.id.day_p2, "setBackgroundResource", R.drawable.bg_day_card);

        // Нажатие открывает главное приложение
        Intent openAppIntent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
			context, 
			0, 
			openAppIntent, 
			PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        views.setOnClickPendingIntent(R.id.widget_root, pendingIntent);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    public static void updateAllWidgets(Context context) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
        ComponentName thisWidget = new ComponentName(context, ShiftWidgetProvider.class);
        int[] appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }
}

