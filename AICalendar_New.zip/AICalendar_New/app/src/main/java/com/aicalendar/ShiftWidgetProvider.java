package com.aicalendar;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.widget.RemoteViews;

import java.util.Calendar;
import java.util.List;

public class ShiftWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    public static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        // Сначала перерассчитываем актуальные данные, чтобы виджет всегда показывал свежий график
        recalculateWidgetData(context);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_shift);
        SharedPreferences prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);

        // 1. Настройка клика по виджету (открываем MainActivity)
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
			context, 
			0, 
			intent, 
			PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Навешиваем клик на весь плашку и на текст
        views.setOnClickPendingIntent(R.id.widget_main_layout, pendingIntent);
        views.setOnClickPendingIntent(R.id.widget_shift_name, pendingIntent);

        // 2. Вывод названия текущей смены
        String todayShiftName = prefs.getString("widget_today_shift_name", "Выходной");
        views.setTextViewText(R.id.widget_shift_name, todayShiftName);

        // 3. Заполнение 3-х дней (Вчера / Сегодня / Завтра)
        int[] dayIds = {R.id.widget_day_1, R.id.widget_day_2, R.id.widget_day_3};
        int[] colorIds = {R.id.widget_color_1, R.id.widget_color_2, R.id.widget_color_3};

        for (int i = 0; i < 3; i++) {
            String dayText = prefs.getString("widget_day_text_" + i, "");
            int color = prefs.getInt("widget_color_" + i, Color.TRANSPARENT);

            views.setTextViewText(dayIds[i], dayText);

            if (color != Color.TRANSPARENT) {
                views.setInt(colorIds[i], "setBackgroundColor", color);
                views.setViewVisibility(colorIds[i], View.VISIBLE);
            } else {
                views.setViewVisibility(colorIds[i], View.INVISIBLE);
            }
        }

        // 4. Финальное обновление самого виджета на экране
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    /**
     * Фоновый расчет графика смен для виджета
     */
    public static void recalculateWidgetData(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);

        // Загрузка сохраненного JSON списка профилей смен
        String profilesJson = prefs.getString("day_profiles_json", "[]");
        List<DayProfile> profiles = ProfileDialog.parseProfilesFromJson(profilesJson);

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1); // Старт со вчерашнего дня

        String todayShiftName = "Выходной";

        for (int i = 0; i < 3; i++) {
            long currentMillis = cal.getTimeInMillis();
            int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);

            String shiftNameForDay = "";
            int colorForDay = Color.TRANSPARENT;

            // Проверяем, подходит ли день под какой-либо из рабочих профилей
            if (profiles != null) {
                for (DayProfile profile : profiles) {
                    if (profile.isActive() && profile.matchesDate(currentMillis)) {
                        shiftNameForDay = profile.getName();
                        colorForDay = profile.getColor();
                        break;
                    }
                }
            }

            // День под индексом 1 — это «Сегодня»
            if (i == 1) {
                todayShiftName = shiftNameForDay.isEmpty() ? "Выходной" : shiftNameForDay;
            }

            // Запоминаем числа и цвета
            prefs.edit()
				.putString("widget_day_text_" + i, String.valueOf(dayOfMonth))
				.putInt("widget_color_" + i, colorForDay)
				.apply();

            cal.add(Calendar.DAY_OF_YEAR, 1);
        }

        prefs.edit().putString("widget_today_shift_name", todayShiftName).apply();
    }

    /**
     * Единый метод вызова обновления виджета из любой точки приложения (MainActivity, диалогов и т.д.)
     */
    public static void updateAllWidgets(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, ShiftWidgetProvider.class));
        for (int id : ids) {
            updateAppWidget(context, manager, id);
        }
    }
}

