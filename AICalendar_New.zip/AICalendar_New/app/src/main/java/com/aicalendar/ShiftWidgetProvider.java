package com.aicalendar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.text.TextUtils;
import android.widget.RemoteViews;

import java.util.Calendar;

public class ShiftWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_WIDGET_UPDATE = "com.aicalendar.ACTION_WIDGET_UPDATE";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        MainActivity.recalculateAndScheduleAlarms(context);
        updateAllWidgets(context);
        scheduleNextMidnightUpdate(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent.getAction();

        if (ACTION_WIDGET_UPDATE.equals(action) 
            || Intent.ACTION_DATE_CHANGED.equals(action) 
            || Intent.ACTION_TIME_CHANGED.equals(action)
            || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
            || Intent.ACTION_BOOT_COMPLETED.equals(action)) {

            MainActivity.recalculateAndScheduleAlarms(context);
            updateAllWidgets(context);
            scheduleNextMidnightUpdate(context);
        }
    }

    public static void updateAllWidgets(Context context) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
        ComponentName thisWidget = new ComponentName(context, ShiftWidgetProvider.class);
        int[] appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
        for (int id : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, id);
        }
    }

    private static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);
        SharedPreferences prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);

        // 0. Цвет фона: подкрашиваем с сохранением скругленных углов
        int defaultBg = Color.argb(204, 36, 39, 46);
        int customBg = prefs.getInt("widget_bg_color_" + appWidgetId, defaultBg);
        views.setInt(R.id.widget_main_layout, "setColorFilter", customBg);

        // 1. Отображение названия дня смены
        String todayShift = prefs.getString("today_shift_name", "");
        if (TextUtils.isEmpty(todayShift)) {
            todayShift = prefs.getString("day_0_name", "2 РАБОЧИЙ");
        }
        views.setTextViewText(R.id.widget_shift_name, todayShift);

        // 2. Отображение ближайшего будильника
        long nextAlarmMs = prefs.getLong("next_alarm_time_ms", 0);
        String alarmLabel = prefs.getString("next_alarm_label", "Будильник");

        if (TextUtils.isEmpty(alarmLabel)) {
            alarmLabel = "Будильник";
        }

        views.setTextViewText(R.id.widget_alarm_title, "⏰ " + alarmLabel);

        long now = System.currentTimeMillis();
        if (nextAlarmMs > now) {
            long diffMs = nextAlarmMs - now;
            long hours = diffMs / (1000 * 60 * 60);
            long minutes = (diffMs / (1000 * 60)) % 60;
            views.setTextViewText(R.id.widget_alarm_time, hours > 0 ? "через " + hours + "ч " + minutes + "м" : "через " + minutes + "м");
        } else {
            boolean isAlarmEnabled = prefs.getBoolean("alarm_enabled", true);
            views.setTextViewText(R.id.widget_alarm_time, isAlarmEnabled ? "включен" : "отключен");
        }

        // 3. Отрисовка 5 дней
        String[] daysOfWeekStr = new String[]{"Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"};
        int[] numIds = new int[]{R.id.day_1_num, R.id.day_2_num, R.id.day_3_num, R.id.day_4_num, R.id.day_5_num};
        int[] subIds = new int[]{R.id.day_1_sub, R.id.day_2_sub, R.id.day_3_sub, R.id.day_4_sub, R.id.day_5_sub};
        int[] bgIds = new int[]{R.id.day_1_bg, R.id.day_2_bg, R.id.day_3_bg, R.id.day_4_bg, R.id.day_5_bg};

        for (int i = 0; i < 5; i++) {
            Calendar cardCal = Calendar.getInstance();
            cardCal.add(Calendar.DAY_OF_MONTH, i - 2);

            int dayNum = cardCal.get(Calendar.DAY_OF_MONTH);
            int dayOfWeekIdx = cardCal.get(Calendar.DAY_OF_WEEK) - 1;

            views.setTextViewText(numIds[i], String.valueOf(dayNum));
            if (i != 2) {
                views.setTextViewText(subIds[i], daysOfWeekStr[dayOfWeekIdx]);
            }

            int color = prefs.getInt("widget_color_" + i, Color.TRANSPARENT);
            if (color != Color.TRANSPARENT) {
                views.setInt(bgIds[i], "setColorFilter", color);
            }
        }

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }

        // 4. Клик по кнопке настроек (btn_settings)
        Intent configIntent = new Intent(context, WidgetConfigActivity.class);
        configIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        configIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent configPendingIntent = PendingIntent.getActivity(context, appWidgetId + 1000, configIntent, flags);
        views.setOnClickPendingIntent(R.id.btn_settings, configPendingIntent);

        // 5. Клик по телу виджета (MainActivity)
        Intent openAppIntent = new Intent(context, MainActivity.class);
        openAppIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, appWidgetId, openAppIntent, flags);

        views.setOnClickPendingIntent(R.id.widget_main_layout, pendingIntent);
        views.setOnClickPendingIntent(R.id.widget_shift_name, pendingIntent);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    private static void scheduleNextMidnightUpdate(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Calendar midnight = Calendar.getInstance();
        midnight.add(Calendar.DAY_OF_MONTH, 1);
        midnight.set(Calendar.HOUR_OF_DAY, 0);
        midnight.set(Calendar.MINUTE, 0);
        midnight.set(Calendar.SECOND, 1);

        Intent intent = new Intent(context, ShiftWidgetProvider.class);
        intent.setAction(ACTION_WIDGET_UPDATE);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 1001, intent, flags);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, midnight.getTimeInMillis(), pendingIntent);
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, midnight.getTimeInMillis(), pendingIntent);
        }
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        SharedPreferences prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        for (int id : appWidgetIds) {
            editor.remove("widget_bg_color_" + id);
        }
        editor.apply();
    }
}

