package com.aicalendar;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.widget.RemoteViews;

public class ShiftWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    public static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        try {
            String pkg = context.getPackageName();

            int layoutId = context.getResources().getIdentifier("widget_shift", "layout", pkg);
            if (layoutId == 0) return; // Ресурс не найден — выходим без падения

            RemoteViews views = new RemoteViews(pkg, layoutId);
            SharedPreferences prefs = context.getSharedPreferences("AiCalendarPrefs", Context.MODE_PRIVATE);

            // Клик по виджету открывает MainActivity
            Intent intent = new Intent(context, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pendingIntent = PendingIntent.getActivity(
                context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            int mainLayoutId = context.getResources().getIdentifier("widget_main_layout", "id", pkg);
            int shiftNameId = context.getResources().getIdentifier("widget_shift_name", "id", pkg);

            if (mainLayoutId != 0) views.setOnClickPendingIntent(mainLayoutId, pendingIntent);
            if (shiftNameId != 0) {
                views.setOnClickPendingIntent(shiftNameId, pendingIntent);
                String todayShiftName = prefs.getString("widget_today_shift_name", "Выходной");
                views.setTextViewText(shiftNameId, todayShiftName);
            }

            // Заполнение 3-х дней
            for (int i = 0; i < 3; i++) {
                int dayViewId = context.getResources().getIdentifier("widget_day_" + (i + 1), "id", pkg);
                int colorViewId = context.getResources().getIdentifier("widget_color_" + (i + 1), "id", pkg);

                if (dayViewId != 0) {
                    String dayText = prefs.getString("widget_day_text_" + i, "");
                    views.setTextViewText(dayViewId, dayText);
                }

                if (colorViewId != 0) {
                    int color = prefs.getInt("widget_color_" + i, Color.TRANSPARENT);
                    if (color != Color.TRANSPARENT) {
                        views.setInt(colorViewId, "setBackgroundColor", color);
                        views.setViewVisibility(colorViewId, View.VISIBLE);
                    } else {
                        views.setViewVisibility(colorViewId, View.INVISIBLE);
                    }
                }
            }

            appWidgetManager.updateAppWidget(appWidgetId, views);
        } catch (Exception e) {
            e.printStackTrace(); // Перехватываем любую ошибку разметки виджета
        }
    }

    public static void updateAllWidgets(Context context) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            if (manager == null) return;
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, ShiftWidgetProvider.class));
            if (ids != null && ids.length > 0) {
                for (int id : ids) {
                    updateAppWidget(context, manager, id);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

