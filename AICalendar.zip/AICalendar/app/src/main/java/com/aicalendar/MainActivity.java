package com.aicalendar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final String PREFS_NAME = "AiCalendarPrefs";
    private static ArrayList<DayProfile> activeProfiles = new ArrayList<>();
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Загрузка сохраненных профилей при запуске
        loadProfilesFromPrefs();

        // Проверка интента (например, если перезапуск по нажатию кнопки/уведомления)
        if (getIntent() != null && getIntent().getBooleanExtra("AUTO_BOOT_RECALC", false)) {
            recalculateAndScheduleAlarms(this);
        }

        Button btnRecalc = findViewById(R.id.btnRecalculate);
        if (btnRecalc != null) {
            btnRecalc.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						recalculateAndScheduleAlarms(MainActivity.this);
						Toast.makeText(MainActivity.this, "Расписание будильников обновлено", Toast.LENGTH_SHORT).show();
					}
				});
        }
    }

    private void loadProfilesFromPrefs() {
        activeProfiles.clear();
        int count = prefs.getInt("profiles_count", 0);

        for (int i = 0; i < count; i++) {
            DayProfile p = new DayProfile();
            p.id = i;
            p.name = prefs.getString("profile_name_" + i, "День " + (i + 1));
            p.period = prefs.getInt("profile_period_" + i, 1);
            p.startTimestamp = prefs.getLong("profile_start_" + i, 0);
            p.color = prefs.getInt("profile_color_" + i, 0xFFCD5C5C);

            int alarmCount = prefs.getInt("profile_alarms_count_" + i, 0);
            for (int a = 0; a < alarmCount; a++) {
                p.alarmTimes.add(prefs.getString("p_" + i + "_alarm_time_" + a, "06:00"));
                p.alarmTasks.add(prefs.getString("p_" + i + "_alarm_task_" + a, ""));
            }
            activeProfiles.add(p);
        }
    }

    public static void recalculateAndScheduleAlarms(final Context context) {
        new Thread(new Runnable() {
				@Override
				public void run() {
					SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

					// Если приложение было закрыто и память очищена — восстанавливаем список профилей
					if (activeProfiles == null || activeProfiles.isEmpty()) {
						activeProfiles = new ArrayList<>();
						int count = prefs.getInt("profiles_count", 0);
						for (int i = 0; i < count; i++) {
							DayProfile p = new DayProfile();
							p.id = i;
							p.name = prefs.getString("profile_name_" + i, "День " + (i + 1));
							p.period = prefs.getInt("profile_period_" + i, 1);
							p.startTimestamp = prefs.getLong("profile_start_" + i, 0);
							p.color = prefs.getInt("profile_color_" + i, 0xFFCD5C5C);

							int alarmCount = prefs.getInt("profile_alarms_count_" + i, 0);
							for (int a = 0; a < alarmCount; a++) {
								p.alarmTimes.add(prefs.getString("p_" + i + "_alarm_time_" + a, "06:00"));
								p.alarmTasks.add(prefs.getString("p_" + i + "_alarm_task_" + a, ""));
							}
							activeProfiles.add(p);
						}
					}

					if (activeProfiles.isEmpty()) {
						return; // Нет профилей для расчета
					}

					AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
					if (alarmManager == null) return;

					// Вычисляем суммарный цикл смены
					int totalCycleDays = 0;
					for (DayProfile p : activeProfiles) {
						totalCycleDays += p.period;
					}

					if (totalCycleDays <= 0) return;

					long now = System.currentTimeMillis();
					Calendar calendar = Calendar.getInstance();

					// Ищем ближайшие срабатывания для всех профилей на ближайшие 30 дней
					class PendingAlarm {
						long triggerTime;
						String task;
						int profileId;
						int alarmIndex;

						PendingAlarm(long triggerTime, String task, int profileId, int alarmIndex) {
							this.triggerTime = triggerTime;
							this.task = task;
							this.profileId = profileId;
							this.alarmIndex = alarmIndex;
						}
					}

					List<PendingAlarm> pendingAlarms = new ArrayList<>();

					for (DayProfile profile : activeProfiles) {
						if (profile.startTimestamp <= 0 || profile.alarmTimes.isEmpty()) continue;

						for (int dayOffset = 0; dayOffset < 30; dayOffset++) {
							calendar.setTimeInMillis(now);
							calendar.add(Calendar.DAY_OF_YEAR, dayOffset);

							// Проверка попадания текущей даты в смену профиля
							long checkDayStart = getStartOfDay(calendar.getTimeInMillis());
							long profileStartDay = getStartOfDay(profile.startTimestamp);

							if (checkDayStart < profileStartDay) continue;

							long diffDays = (checkDayStart - profileStartDay) / (24 * 60 * 60 * 1000);
							long cyclePos = diffDays % totalCycleDays;

							// Находим смещение профиля внутри общего цикла
							int currentOffset = 0;
							boolean matchesProfile = false;
							for (DayProfile p : activeProfiles) {
								if (p.id == profile.id) {
									if (cyclePos >= currentOffset && cyclePos < (currentOffset + p.period)) {
										matchesProfile = true;
									}
									break;
								}
								currentOffset += p.period;
							}

							if (matchesProfile) {
								for (int a = 0; a < profile.alarmTimes.size(); a++) {
									String timeStr = profile.alarmTimes.get(a);
									String[] parts = timeStr.split(":");
									if (parts.length != 2) continue;

									int hour = Integer.parseInt(parts[0]);
									int minute = Integer.parseInt(parts[1]);

									Calendar alarmCal = (Calendar) calendar.clone();
									alarmCal.set(Calendar.HOUR_OF_DAY, hour);
									alarmCal.set(Calendar.MINUTE, minute);
									alarmCal.set(Calendar.SECOND, 0);
									alarmCal.set(Calendar.MILLISECOND, 0);

									long triggerTime = alarmCal.getTimeInMillis();

									// Пропускаем прошедшие по времени и вручную отключенные будильники
									boolean isDisabled = prefs.getBoolean("disabled_alarm_" + profile.id + "_" + triggerTime, false);
									if (triggerTime > now && !isDisabled) {
										String task = (a < profile.alarmTasks.size()) ? profile.alarmTasks.get(a) : "";
										pendingAlarms.add(new PendingAlarm(triggerTime, task, profile.id, a));
									}
								}
							}
						}
					}

					// Сортируем будильники по времени срабатывания
					Collections.sort(pendingAlarms, new Comparator<PendingAlarm>() {
							@Override
							public int compare(PendingAlarm o1, PendingAlarm o2) {
								return Long.compare(o1.triggerTime, o2.triggerTime);
							}
						});

					// Ставим системный будильник на самое ближайшее событие
					if (!pendingAlarms.isEmpty()) {
						PendingAlarm nextAlarm = pendingAlarms.get(0);

						Intent intent = new Intent(context, AlarmReceiver.class);
						intent.putExtra("EXTRA_TASK", nextAlarm.task);
						intent.putExtra("EXTRA_PROFILE_ID", nextAlarm.profileId);
						intent.putExtra("EXTRA_TRIGGER_TIME", nextAlarm.triggerTime);

						PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            context,
                            1001,
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
						);

						if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
							alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextAlarm.triggerTime, pendingIntent);
						} else {
							alarmManager.set(AlarmManager.RTC_WAKEUP, nextAlarm.triggerTime, pendingIntent);
						}
					}
				}
			}).start();
    }

    private static long getStartOfDay(long timestamp) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(timestamp);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    // Простой вложенный класс для представительства структуры профиля
    public static class DayProfile {
        public int id;
        public String name;
        public int period = 1;
        public long startTimestamp;
        public int color;
        public ArrayList<String> alarmTimes = new ArrayList<>();
        public ArrayList<String> alarmTasks = new ArrayList<>();
    }
}

