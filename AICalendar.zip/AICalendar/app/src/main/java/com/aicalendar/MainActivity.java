package com.aicalendar;

import com.aicalendar.R;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final String PREFS_NAME = "AiCalendarPrefs";
    private static ArrayList<DayProfile> activeProfiles = new ArrayList<>();
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Указываем ваш исходный файл main.xml
        setContentView(R.layout.main);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Загрузка сохраненных профилей при запуске
        loadProfilesFromPrefs();

        if (getIntent() != null && getIntent().getBooleanExtra("AUTO_BOOT_RECALC", false)) {
            recalculateAndScheduleAlarms(this);
        }

        // Поиск кнопки пересчета из main.xml
        int btnId = getResources().getIdentifier("btnRecalculate", "id", getPackageName());
        if (btnId != 0) {
            Button btnRecalc = findViewById(btnId);
            if (btnRecalc != null) {
                btnRecalc.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							recalculateAndScheduleAlarms(MainActivity.this);
							Toast.makeText(MainActivity.this, "Расписание будильников обновлено", Toast.LENGTH_SHORT).show();
						}
					});
            }
        }
    }

    private void loadProfilesFromPrefs() {
        activeProfiles.clear();
        int count = prefs.getInt("profiles_count", 0);

        for (int i = 0; i < count; i++) {
            DayProfile p = new DayProfile();
            p.id = i;
            p.name = prefs.getString("profile_name_" + i, "День " + (i + 1));
            p.period = prefs.getInt("profile_period_" + i, 1);
            p.startTimestamp = prefs.getLong("profile_start_" + i, 0);
            p.color = prefs.getInt("profile_color_" + i, 0xFFCD5C5C);

            int alarmCount = prefs.getInt("profile_alarms_count_" + i, 0);
            for (int a = 0; a < alarmCount; a++) {
                p.alarmTimes.add(prefs.getString("p_" + i + "_alarm_time_" + a, "06:00"));
                p.alarmTasks.add(prefs.getString("p_" + i + "_alarm_task_" + a, ""));
            }
            activeProfiles.add(p);
        }
    }

    // --- Методы взаимодействия с ProfileDialog ---

    public String getProfileName(int index) {
        if (index >= 0 && index < activeProfiles.size()) {
            return activeProfiles.get(index).name;
        }
        return "";
    }

    public int getProfilePeriod(int index) {
        if (index >= 0 && index < activeProfiles.size()) {
            return activeProfiles.get(index).period;
        }
        return 1;
    }

    public int getProfileColor(int index) {
        if (index >= 0 && index < activeProfiles.size()) {
            return activeProfiles.get(index).color;
        }
        return 0xFFCD5C5C;
    }

    public void fillAlarmRows(int index, LinearLayout container, ArrayList<EditText> times, ArrayList<EditText> tasks) {
        container.removeAllViews();
        times.clear();
        tasks.clear();

        if (index >= 0 && index < activeProfiles.size()) {
            DayProfile p = activeProfiles.get(index);
            for (int i = 0; i < p.alarmTimes.size(); i++) {
                String time = p.alarmTimes.get(i);
                String task = (i < p.alarmTasks.size()) ? p.alarmTasks.get(i) : "";
                addAlarmRowExternal(container, times, tasks, time, task);
            }
        }
    }

    public void addAlarmRowExternal(LinearLayout container, ArrayList<EditText> times, ArrayList<EditText> tasks, String defaultTime, String defaultTask) {
        int itemLayoutId = getResources().getIdentifier("dialog_alarm_settings", "layout", getPackageName());
        if (itemLayoutId == 0) return;

        View rowView = LayoutInflater.from(this).inflate(itemLayoutId, container, false);

        int timeId = getResources().getIdentifier("etAlarmTime", "id", getPackageName());
        int taskId = getResources().getIdentifier("etAlarmTask", "id", getPackageName());
        int deleteId = getResources().getIdentifier("btnDeleteAlarm", "id", getPackageName());

        EditText etTime = timeId != 0 ? rowView.findViewById(timeId) : null;
        EditText etTask = taskId != 0 ? rowView.findViewById(taskId) : null;
        View btnDelete = deleteId != 0 ? rowView.findViewById(deleteId) : null;

        if (etTime != null) etTime.setText(defaultTime);
        if (etTask != null) etTask.setText(defaultTask);

        if (btnDelete != null) {
            btnDelete.setOnClickListener(v -> {
                container.removeView(rowView);
                if (etTime != null) times.remove(etTime);
                if (etTask != null) tasks.remove(etTask);
            });
        }

        if (etTime != null) times.add(etTime);
        if (etTask != null) tasks.add(etTask);
        container.addView(rowView);
    }

    public void deleteProfileExternal(int index) {
        if (index >= 0 && index < activeProfiles.size()) {
            activeProfiles.remove(index);
            saveProfilesToPrefs();
            recalculateAndScheduleAlarms(this);
        }
    }

    public void saveProfileExternal(int index, String name, int period, int color, ArrayList<EditText> times, ArrayList<EditText> tasks) {
        DayProfile p;
        if (index >= 0 && index < activeProfiles.size()) {
            p = activeProfiles.get(index);
        } else {
            p = new DayProfile();
            p.id = activeProfiles.size();
            p.startTimestamp = System.currentTimeMillis();
            activeProfiles.add(p);
        }

        p.name = name;
        p.period = period;
        p.color = color;
        p.alarmTimes.clear();
        p.alarmTasks.clear();

        for (int i = 0; i < times.size(); i++) {
            p.alarmTimes.add(times.get(i).getText().toString().trim());
            p.alarmTasks.add(tasks.get(i).getText().toString().trim());
        }

        saveProfilesToPrefs();
        recalculateAndScheduleAlarms(this);
    }

    private void saveProfilesToPrefs() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("profiles_count", activeProfiles.size());

        for (int i = 0; i < activeProfiles.size(); i++) {
            DayProfile p = activeProfiles.get(i);
            editor.putString("profile_name_" + i, p.name);
            editor.putInt("profile_period_" + i, p.period);
            editor.putLong("profile_start_" + i, p.startTimestamp);
            editor.putInt("profile_color_" + i, p.color);
            editor.putInt("profile_alarms_count_" + i, p.alarmTimes.size());

            for (int a = 0; a < p.alarmTimes.size(); a++) {
                editor.putString("p_" + i + "_alarm_time_" + a, p.alarmTimes.get(a));
                editor.putString("p_" + i + "_alarm_task_" + a, (a < p.alarmTasks.size()) ? p.alarmTasks.get(a) : "");
            }
        }
        editor.apply();
    }

    // --- Логика пересчета и взвода будильников ---

    public static void recalculateAndScheduleAlarms(final Context context) {
        new Thread(new Runnable() {
				@Override
				public void run() {
					SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

					if (activeProfiles == null || activeProfiles.isEmpty()) {
						activeProfiles = new ArrayList<>();
						int count = prefs.getInt("profiles_count", 0);
						for (int i = 0; i < count; i++) {
							DayProfile p = new DayProfile();
							p.id = i;
							p.name = prefs.getString("profile_name_" + i, "День " + (i + 1));
							p.period = prefs.getInt("profile_period_" + i, 1);
							p.startTimestamp = prefs.getLong("profile_start_" + i, 0);
							p.color = prefs.getInt("profile_color_" + i, 0xFFCD5C5C);

							int alarmCount = prefs.getInt("profile_alarms_count_" + i, 0);
							for (int a = 0; a < alarmCount; a++) {
								p.alarmTimes.add(prefs.getString("p_" + i + "_alarm_time_" + a, "06:00"));
								p.alarmTasks.add(prefs.getString("p_" + i + "_alarm_task_" + a, ""));
							}
							activeProfiles.add(p);
						}
					}

					if (activeProfiles.isEmpty()) return;

					AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
					if (alarmManager == null) return;

					int totalCycleDays = 0;
					for (DayProfile p : activeProfiles) {
						totalCycleDays += p.period;
					}

					if (totalCycleDays <= 0) return;

					long now = System.currentTimeMillis();
					Calendar calendar = Calendar.getInstance();

					class PendingAlarm {
						long triggerTime;
						String task;
						int profileId;

						PendingAlarm(long triggerTime, String task, int profileId) {
							this.triggerTime = triggerTime;
							this.task = task;
							this.profileId = profileId;
						}
					}

					List<PendingAlarm> pendingAlarms = new ArrayList<>();

					for (DayProfile profile : activeProfiles) {
						if (profile.startTimestamp <= 0 || profile.alarmTimes.isEmpty()) continue;

						for (int dayOffset = 0; dayOffset < 30; dayOffset++) {
							calendar.setTimeInMillis(now);
							calendar.add(Calendar.DAY_OF_YEAR, dayOffset);

							long checkDayStart = getStartOfDay(calendar.getTimeInMillis());
							long profileStartDay = getStartOfDay(profile.startTimestamp);

							if (checkDayStart < profileStartDay) continue;

							long diffDays = (checkDayStart - profileStartDay) / (24 * 60 * 60 * 1000);
							long cyclePos = diffDays % totalCycleDays;

							int currentOffset = 0;
							boolean matchesProfile = false;
							for (DayProfile p : activeProfiles) {
								if (p.id == profile.id) {
									if (cyclePos >= currentOffset && cyclePos < (currentOffset + p.period)) {
										matchesProfile = true;
									}
									break;
								}
								currentOffset += p.period;
							}

							if (matchesProfile) {
								for (int a = 0; a < profile.alarmTimes.size(); a++) {
									String timeStr = profile.alarmTimes.get(a);
									String[] parts = timeStr.split(":");
									if (parts.length != 2) continue;

									try {
										int hour = Integer.parseInt(parts[0].trim());
										int minute = Integer.parseInt(parts[1].trim());

										Calendar alarmCal = (Calendar) calendar.clone();
										alarmCal.set(Calendar.HOUR_OF_DAY, hour);
										alarmCal.set(Calendar.MINUTE, minute);
										alarmCal.set(Calendar.SECOND, 0);
										alarmCal.set(Calendar.MILLISECOND, 0);

										long triggerTime = alarmCal.getTimeInMillis();
										boolean isDisabled = prefs.getBoolean("disabled_alarm_" + profile.id + "_" + triggerTime, false);

										if (triggerTime > now && !isDisabled) {
											String task = (a < profile.alarmTasks.size()) ? profile.alarmTasks.get(a) : "";
											pendingAlarms.add(new PendingAlarm(triggerTime, task, profile.id));
										}
									} catch (NumberFormatException ignored) {}
								}
							}
						}
					}

					Collections.sort(pendingAlarms, new Comparator<PendingAlarm>() {
							@Override
							public int compare(PendingAlarm o1, PendingAlarm o2) {
								return Long.compare(o1.triggerTime, o2.triggerTime);
							}
						});

					if (!pendingAlarms.isEmpty()) {
						PendingAlarm nextAlarm = pendingAlarms.get(0);

						Intent intent = new Intent(context, AlarmReceiver.class);
						intent.putExtra("EXTRA_TASK", nextAlarm.task);
						intent.putExtra("EXTRA_PROFILE_ID", nextAlarm.profileId);
						intent.putExtra("EXTRA_TRIGGER_TIME", nextAlarm.triggerTime);

						PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            context,
                            1001,
                            intent,
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
						);

						if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
							alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextAlarm.triggerTime, pendingIntent);
						} else {
							alarmManager.set(AlarmManager.RTC_WAKEUP, nextAlarm.triggerTime, pendingIntent);
						}
					}
				}
			}).start();
    }

    private static long getStartOfDay(long timestamp) {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(timestamp);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    public static class DayProfile {
        public int id;
        public String name;
        public int period = 1;
        public long startTimestamp;
        public int color;
        public ArrayList<String> alarmTimes = new ArrayList<>();
        public ArrayList<String> alarmTasks = new ArrayList<>();
    }
}

