package com.aicalendar;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private CalendarPagerAdapter pagerAdapter;
    private List<DayProfile> activeProfiles = new ArrayList<>();
    private Uri tempRingtoneUri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Проверка разрешения на точные будильники (Android 12+)
        checkExactAlarmPermission();

        viewPager = findViewById(R.id.viewPager);
        pagerAdapter = new CalendarPagerAdapter();
        viewPager.setAdapter(pagerAdapter);
        viewPager.setCurrentItem(1000); // Центрируем на текущий месяц

        Button btnSettings = findViewById(R.id.btnSettings);
        if (btnSettings != null) {
            btnSettings.setOnClickListener(v -> {
                ProfileDialog dialog = new ProfileDialog(MainActivity.this, profiles -> {
                    activeProfiles = profiles;
                    pagerAdapter.notifyDataSetChanged();
                    recalculateAndScheduleAlarms();
                });
                dialog.show();
            });
        }

        loadProfilesFromPrefs();
    }

    private void checkExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (alarmManager != null && !alarmManager.canScheduleExactAlarms()) {
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void loadProfilesFromPrefs() {
        SharedPreferences prefs = getSharedPreferences("CalendarPrefs", MODE_PRIVATE);
        String json = prefs.getString("profiles_json", "[]");
        activeProfiles.clear();
        try {
            JSONArray array = new JSONArray(json);
            for (int i = 0; i < array.length(); i++) {
                activeProfiles.add(DayProfile.fromJson(array.getJSONObject(i)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (pagerAdapter != null) {
            pagerAdapter.notifyDataSetChanged();
        }
    }

    private void recalculateAndScheduleAlarms() {
        if (activeProfiles == null || activeProfiles.isEmpty()) return;

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Calendar now = Calendar.getInstance();
        long nowMillis = now.getTimeInMillis();

        for (DayProfile profile : activeProfiles) {
            if (profile.startTimestamp == 0 || profile.alarmTimes.isEmpty()) continue;

            Calendar startCal = Calendar.getInstance();
            startCal.setTimeInMillis(profile.startTimestamp);
            startCal.set(Calendar.HOUR_OF_DAY, 0);
            startCal.set(Calendar.MINUTE, 0);
            startCal.set(Calendar.SECOND, 0);
            startCal.set(Calendar.MILLISECOND, 0);

            Calendar checkCal = (Calendar) startCal.clone();

            // Ищем ближайший будущий день по периоду
            while (checkCal.getTimeInMillis() < nowMillis - 86400000L) {
                checkCal.add(Calendar.DAY_OF_YEAR, profile.period);
            }

            for (String timeStr : profile.alarmTimes) {
                String[] parts = timeStr.split(":");
                if (parts.length != 2) continue;

                int hour = Integer.parseInt(parts[0]);
                int minute = Integer.parseInt(parts[1]);

                Calendar alarmCal = (Calendar) checkCal.clone();
                alarmCal.set(Calendar.HOUR_OF_DAY, hour);
                alarmCal.set(Calendar.MINUTE, minute);
                alarmCal.set(Calendar.SECOND, 0);

                if (alarmCal.getTimeInMillis() <= nowMillis) {
                    alarmCal.add(Calendar.DAY_OF_YEAR, profile.period);
                }

                Intent intent = new Intent(this, AlarmReceiver.class);
                intent.putExtra("PROFILE_NAME", profile.name);
                intent.putExtra("ALARM_TIME", timeStr);

                PendingIntent pendingIntent = PendingIntent.getBroadcast(
					this,
					(profile.name + timeStr).hashCode(),
					intent,
					PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alarmCal.getTimeInMillis(), pendingIntent);
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, alarmCal.getTimeInMillis(), pendingIntent);
                }
            }
        }

        // Обновляем виджет при изменении расписания
        Intent updateWidgetIntent = new Intent("com.aicalendar.UPDATE_WIDGET");
        sendBroadcast(updateWidgetIntent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri selectedAudioUri = data.getData();

            // Сохраняем постоянные права на чтение URI
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                try {
                    getContentResolver().takePersistableUriPermission(
						selectedAudioUri, 
						Intent.FLAG_GRANT_READ_URI_PERMISSION
                    );
                } catch (SecurityException ignored) {}
            }

            if (requestCode == 888) { // Пре-будильник
                copyUriToFile(selectedAudioUri, "custom_pre_alarm.mp3");
                Toast.makeText(this, "Звук пре-будильника сохранен", Toast.LENGTH_SHORT).show();
            } else if (requestCode == 999) { // Основной рингтон
                tempRingtoneUri = selectedAudioUri;
                Toast.makeText(this, "Мелодия выбрана", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void copyUriToFile(Uri uri, String fileName) {
        try (InputStream is = getContentResolver().openInputStream(uri);
		FileOutputStream fos = openFileOutput(fileName, Context.MODE_PRIVATE)) {
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                fos.write(buffer, 0, length);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // --- PAGER ADAPTER ---
    private class CalendarPagerAdapter extends PagerAdapter {

        @Override
        public int getCount() {
            return 2000; // Позволяет листать назад и вперед на годы
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            GridView gridView = new GridView(MainActivity.this);
            gridView.setNumColumns(7);

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.MONTH, position - 1000);
            cal.set(Calendar.DAY_OF_MONTH, 1);

            GridAdapter adapter = new GridAdapter(cal);
            gridView.setAdapter(adapter);

            container.addView(gridView);
            return gridView;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        @Override
        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }
    }

    // --- GRID ADAPTER ---
    private class GridAdapter extends BaseAdapter {
        private List<Calendar> days = new ArrayList<>();
        private Calendar currentMonth;
        private int zoneOffset;

        public GridAdapter(Calendar monthCal) {
            this.currentMonth = (Calendar) monthCal.clone();
            this.zoneOffset = TimeZone.getDefault().getOffset(System.currentTimeMillis());

            Calendar cal = (Calendar) monthCal.clone();
            int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 2;
            if (firstDayOfWeek < 0) firstDayOfWeek += 7;

            cal.add(Calendar.DAY_OF_MONTH, -firstDayOfWeek);

            while (days.size() < 42) { // 6 недель для полной сетки
                days.add((Calendar) cal.clone());
                cal.add(Calendar.DAY_OF_MONTH, 1);
            }
        }

        @Override
        public int getCount() {
            return days.size();
        }

        @Override
        public Object getItem(int position) {
            return days.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Calendar date = days.get(position);
            DayTileView tileView;

            if (convertView == null) {
                tileView = new DayTileView(MainActivity.this);
            } else {
                tileView = (DayTileView) convertView;
            }

            int dayNum = date.get(Calendar.DAY_OF_MONTH);
            tileView.setText(String.valueOf(dayNum));

            // Проверка на текущий месяц
            boolean isSameMonth = date.get(Calendar.MONTH) == currentMonth.get(Calendar.MONTH);
            tileView.setAlpha(isSameMonth ? 1.0f : 0.35f);

            // Проверка на "Сегодня"
            Calendar today = Calendar.getInstance();
            boolean isToday = (date.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
				date.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR));
            tileView.setToday(isToday);

            // Проверка профилей и цвета
            int matchedColor = Color.TRANSPARENT;
            boolean hasAlarms = false;

            long localCheckTime = date.getTimeInMillis() + zoneOffset;
            long checkTime = (localCheckTime / 86400000L) * 86400000L;

            if (activeProfiles != null) {
                for (DayProfile p : activeProfiles) {
                    if (p.startTimestamp == 0) continue;

                    long localStartTime = p.startTimestamp + zoneOffset;
                    long startZero = (localStartTime / 86400000L) * 86400000L;

                    long diff = checkTime - startZero;
                    if (diff >= 0) {
                        long daysDiff = diff / 86400000L;
                        if (daysDiff % p.period == 0) {
                            matchedColor = p.color;
                            hasAlarms = !p.alarmTimes.isEmpty();
                            break;
                        }
                    }
                }
            }

            tileView.setBackgroundColor(matchedColor);
            tileView.setHasAlarms(hasAlarms);

            tileView.setOnClickListener(v -> showDayActionDialog(date));

            return tileView;
        }
    }

    private void showDayActionDialog(Calendar date) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(date.get(Calendar.DAY_OF_MONTH) + "/" + (date.get(Calendar.MONTH) + 1) + "/" + date.get(Calendar.YEAR));
        builder.setMessage("Управление сменой и событиями дня");
        builder.setPositiveButton("ОК", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    // --- CUSTOM TILE VIEW ---
    private class DayTileView extends androidx.appcompat.widget.AppCompatTextView {
        private boolean hasAlarms = false;
        private boolean isToday = false;
        private Paint todayPaint;
        private Paint alarmDotPaint;
        private Rect textBounds = new Rect(); // Вынесено из onDraw для производительности

        public DayTileView(Context context) {
            super(context);
            init();
        }

        private void init() {
            setGravity(android.view.Gravity.CENTER);
            setPadding(8, 16, 8, 16);
            setTextSize(16);
            setTextColor(Color.WHITE);

            todayPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            todayPaint.setColor(Color.RED);
            todayPaint.setStyle(Paint.Style.STROKE);
            todayPaint.setStrokeWidth(4f);

            alarmDotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            alarmDotPaint.setColor(Color.YELLOW);
            alarmDotPaint.setStyle(Paint.Style.FILL);
        }

        public void setToday(boolean today) {
            this.isToday = today;
            invalidate();
        }

        public void setHasAlarms(boolean hasAlarms) {
            this.hasAlarms = hasAlarms;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            int width = getWidth();
            int height = getHeight();

            if (isToday) {
                canvas.drawRect(2, 2, width - 2, height - 2, todayPaint);
            }

            if (hasAlarms) {
                canvas.drawCircle(width - 12, 12, 6, alarmDotPaint);
            }
        }
    }

    // Вспомогательный класс профиля (если не вынесен в отдельный файл)
    public static class DayProfile {
        public String name;
        public int color;
        public int period;
        public long startTimestamp;
        public List<String> alarmTimes = new ArrayList<>();

        public static DayProfile fromJson(JSONObject json) {
            DayProfile profile = new DayProfile();
            try {
                profile.name = json.optString("name", "");
                profile.color = json.optInt("color", Color.GRAY);
                profile.period = json.optInt("period", 1);
                profile.startTimestamp = json.optLong("startTimestamp", 0);
                JSONArray array = json.optJSONArray("alarmTimes");
                if (array != null) {
                    for (int i = 0; i < array.length(); i++) {
                        profile.alarmTimes.add(array.getString(i));
                    }
                }
			} catch (Exception e) {
				e.printStackTrace();
			}
			
            return profile;
        }
    }
}

