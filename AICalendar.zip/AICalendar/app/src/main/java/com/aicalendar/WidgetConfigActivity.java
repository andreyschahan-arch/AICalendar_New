package com.aicalendar;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

public class WidgetConfigActivity extends Activity {

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private int selectedTextColor = 0xFFFFFFFF; // По умолчанию белый

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_widget_config);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        // Если применили как прямое конфигурирование из ОС
        setResult(RESULT_CANCELED);

        SeekBar sbAlpha = findViewById(R.id.sb_widget_alpha);
        Button btnWhite = findViewById(R.id.btn_text_white);
        Button btnDark = findViewById(R.id.btn_text_dark);
        Button btnApply = findViewById(R.id.btn_apply_config);
        View bgTouchOutside = findViewById(R.id.bg_touch_outside);

        SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        sbAlpha.setProgress(prefs.getInt("widget_alpha", 180));

        btnWhite.setOnClickListener(v -> selectedTextColor = 0xFFFFFFFF);
        btnDark.setOnClickListener(v -> selectedTextColor = 0xFF222222);

        bgTouchOutside.setOnClickListener(v -> finish());

        btnApply.setOnClickListener(v -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt("widget_alpha", sbAlpha.getProgress());
            editor.putInt("widget_text_color", selectedTextColor);
            editor.apply();

            // Принудительно обновляем виджет
            ShiftWidgetProvider.updateAllWidgets(WidgetConfigActivity.this);

            Intent resultValue = new Intent();
            resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            setResult(RESULT_OK, resultValue);
            finish();
        });
    }
}

