package com.aicalendar;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

public class WidgetConfigActivity extends Activity {

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private int selectedStyle = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_widget_config);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }

        View b1 = findViewById(R.id.btn_bg_style_1);
        View b2 = findViewById(R.id.btn_bg_style_2);
        View b3 = findViewById(R.id.btn_bg_style_3);
        View b4 = findViewById(R.id.btn_bg_style_4);
        View b5 = findViewById(R.id.btn_bg_style_5);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id = v.getId();
                if (id == R.id.btn_bg_style_1) selectedStyle = 1;
                else if (id == R.id.btn_bg_style_2) selectedStyle = 2;
                else if (id == R.id.btn_bg_style_3) selectedStyle = 3;
                else if (id == R.id.btn_bg_style_4) selectedStyle = 4;
                else if (id == R.id.btn_bg_style_5) selectedStyle = 5;
            }
        };

        b1.setOnClickListener(listener);
        b2.setOnClickListener(listener);
        b3.setOnClickListener(listener);
        b4.setOnClickListener(listener);
        b5.setOnClickListener(listener);

        findViewById(R.id.btn_save_widget).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
					prefs.edit().putInt("widget_bg_style_" + appWidgetId, selectedStyle).apply();

					AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(WidgetConfigActivity.this);
					ShiftWidgetProvider.updateAppWidget(WidgetConfigActivity.this, appWidgetManager, appWidgetId);

					Intent resultValue = new Intent();
					resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
					setResult(RESULT_OK, resultValue);
					finish();
				}
			});
    }
}

