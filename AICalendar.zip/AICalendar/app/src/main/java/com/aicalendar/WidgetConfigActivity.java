package com.aicalendar;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

public class WidgetConfigActivity extends Activity {

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private int selectedStyle = 1;
    private int selectedTextColor = Color.WHITE;

    private View b1, b2, b3, b4, b5;
    private View btnWhite, btnDark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_widget_config);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }

        // --- Загрузка сохранённых настроек ---
        SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        selectedStyle = prefs.getInt("widget_bg_style_" + appWidgetId, 1);
        selectedTextColor = prefs.getInt("widget_text_color_" + appWidgetId, Color.WHITE);

        // Кнопки фона
        b1 = findViewById(R.id.btn_bg_style_1);
        b2 = findViewById(R.id.btn_bg_style_2);
        b3 = findViewById(R.id.btn_bg_style_3);
        b4 = findViewById(R.id.btn_bg_style_4);
        b5 = findViewById(R.id.btn_bg_style_5);

        View.OnClickListener bgListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id = v.getId();
                if (id == R.id.btn_bg_style_1) selectedStyle = 1;
                else if (id == R.id.btn_bg_style_2) selectedStyle = 2;
                else if (id == R.id.btn_bg_style_3) selectedStyle = 3;
                else if (id == R.id.btn_bg_style_4) selectedStyle = 4;
                else if (id == R.id.btn_bg_style_5) selectedStyle = 5;

                updateBgSelection();
            }
        };

        if (b1 != null) b1.setOnClickListener(bgListener);
        if (b2 != null) b2.setOnClickListener(bgListener);
        if (b3 != null) b3.setOnClickListener(bgListener);
        if (b4 != null) b4.setOnClickListener(bgListener);
        if (b5 != null) b5.setOnClickListener(bgListener);

        // Кнопки цвета текста
        btnWhite = findViewById(R.id.btn_text_white);
        btnDark = findViewById(R.id.btn_text_dark);

        if (btnWhite != null) {
            btnWhite.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						selectedTextColor = Color.WHITE;
						updateTextColorSelection();
					}
				});
        }

        if (btnDark != null) {
            btnDark.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						selectedTextColor = Color.parseColor("#1C1C1E");
						updateTextColorSelection();
					}
				});
        }

        // Кнопка Применить
        findViewById(R.id.btn_save_widget).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
					prefs.edit()
                        .putInt("widget_bg_style_" + appWidgetId, selectedStyle)
                        .putInt("widget_text_color_" + appWidgetId, selectedTextColor)
                        .apply();

					AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(WidgetConfigActivity.this);
					ShiftWidgetProvider.updateAppWidget(WidgetConfigActivity.this, appWidgetManager, appWidgetId);

					Intent resultValue = new Intent();
					resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
					setResult(RESULT_OK, resultValue);
					finish();
				}
			});

        // Отображение текущего выбора
        updateBgSelection();
        updateTextColorSelection();
    }

    private void updateBgSelection() {
        View[] bgViews = {b1, b2, b3, b4, b5};
        for (int i = 0; i < bgViews.length; i++) {
            if (bgViews[i] != null) {
                if (i + 1 == selectedStyle) {
                    bgViews[i].setAlpha(1.0f);
                    bgViews[i].setScaleX(1.25f);
                    bgViews[i].setScaleY(1.25f);
                } else {
                    bgViews[i].setAlpha(0.4f);
                    bgViews[i].setScaleX(1.0f);
                    bgViews[i].setScaleY(1.0f);
                }
            }
        }
    }

    private void updateTextColorSelection() {
        if (btnWhite != null && btnDark != null) {
            if (selectedTextColor == Color.WHITE) {
                btnWhite.setAlpha(1.0f);
                btnWhite.setScaleX(1.25f);
                btnWhite.setScaleY(1.25f);

                btnDark.setAlpha(0.4f);
                btnDark.setScaleX(1.0f);
                btnDark.setScaleY(1.0f);
            } else {
                btnDark.setAlpha(1.0f);
                btnDark.setScaleX(1.25f);
                btnDark.setScaleY(1.25f);

                btnWhite.setAlpha(0.4f);
                btnWhite.setScaleX(1.0f);
                btnWhite.setScaleY(1.0f);
            }
        }
    }
}

