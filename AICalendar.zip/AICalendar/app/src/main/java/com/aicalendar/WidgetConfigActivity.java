package com.aicalendar;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;

public class WidgetConfigActivity extends Activity {

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private int selectedStyle = 1;
    private int selectedAlpha = 255;
    private int selectedTextColor = Color.WHITE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_widget_config);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }

        // Выбор фона
        View b1 = findViewById(R.id.btn_bg_style_1);
        View b2 = findViewById(R.id.btn_bg_style_2);
        View b3 = findViewById(R.id.btn_bg_style_3);
        View b4 = findViewById(R.id.btn_bg_style_4);
        View b5 = findViewById(R.id.btn_bg_style_5);

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id = v.getId();
                if (id == R.id.btn_bg_style_1) selectedStyle = 1;
                else if (id == R.id.btn_bg_style_2) selectedStyle = 2;
                else if (id == R.id.btn_bg_style_3) selectedStyle = 3;
                else if (id == R.id.btn_bg_style_4) selectedStyle = 4;
                else if (id == R.id.btn_bg_style_5) selectedStyle = 5;
            }
        };

        if (b1 != null) b1.setOnClickListener(listener);
        if (b2 != null) b2.setOnClickListener(listener);
        if (b3 != null) b3.setOnClickListener(listener);
        if (b4 != null) b4.setOnClickListener(listener);
        if (b5 != null) b5.setOnClickListener(listener);

        // Ползунок прозрачности
        SeekBar alphaSeekBar = findViewById(R.id.seekbar_alpha);
        if (alphaSeekBar != null) {
            alphaSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
					@Override
					public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
						selectedAlpha = progress;
					}
					@Override public void onStartTrackingTouch(SeekBar seekBar) {}
					@Override public void onStopTrackingTouch(SeekBar seekBar) {}
				});
        }

        // Цвет текста (Светлый / Тёмный)
        View btnWhite = findViewById(R.id.btn_text_white);
        View btnDark = findViewById(R.id.btn_text_dark);

        if (btnWhite != null) {
            btnWhite.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						selectedTextColor = Color.WHITE;
					}
				});
        }

        if (btnDark != null) {
            btnDark.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						selectedTextColor = Color.parseColor("#1C1C1E");
					}
				});
        }

        // Кнопка Применить
        findViewById(R.id.btn_save_widget).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
					prefs.edit()
                        .putInt("widget_bg_style_" + appWidgetId, selectedStyle)
                        .putInt("widget_alpha_" + appWidgetId, selectedAlpha)
                        .putInt("widget_text_color_" + appWidgetId, selectedTextColor)
                        .apply();

					AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(WidgetConfigActivity.this);
					ShiftWidgetProvider.updateAppWidget(WidgetConfigActivity.this, appWidgetManager, appWidgetId);

					Intent resultValue = new Intent();
					resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
					setResult(RESULT_OK, resultValue);
					finish();
				}
			});
    }
}

