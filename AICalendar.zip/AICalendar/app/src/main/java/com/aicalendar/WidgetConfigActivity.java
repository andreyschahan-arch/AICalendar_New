package com.aicalendar;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

public class WidgetConfigActivity extends Activity {

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private int selectedAlpha = 180;
    private int selectedTextColor = Color.WHITE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_widget_config);

        // Получаем ID виджета
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        // Если ID неверный — закрываем
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }

        SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        selectedAlpha = prefs.getInt("widget_alpha_" + appWidgetId, 180);
        selectedTextColor = prefs.getInt("widget_text_color_" + appWidgetId, Color.WHITE);

        SeekBar sbAlpha = findViewById(R.id.sb_widget_alpha);
        Button btnWhite = findViewById(R.id.btn_text_white);
        Button btnDark = findViewById(R.id.btn_text_dark);
        Button btnApply = findViewById(R.id.btn_apply_config);
        View bgOutside = findViewById(R.id.bg_touch_outside);

        if (sbAlpha != null) {
            sbAlpha.setProgress(selectedAlpha);
            sbAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
					@Override
					public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
						selectedAlpha = progress;
					}
					@Override public void onStartTrackingTouch(SeekBar seekBar) {}
					@Override public void onStopTrackingTouch(SeekBar seekBar) {}
				});
        }

        if (btnWhite != null) {
            btnWhite.setOnClickListener(v -> selectedTextColor = Color.WHITE);
        }

        if (btnDark != null) {
            btnDark.setOnClickListener(v -> selectedTextColor = Color.BLACK);
        }

        // Закрытие при клике мимо шторки
        if (bgOutside != null) {
            bgOutside.setOnClickListener(v -> finish());
        }

        // Сохранение и обновление виджета
        if (btnApply != null) {
            btnApply.setOnClickListener(v -> {
                SharedPreferences.Editor editor = prefs.edit();
                editor.putInt("widget_alpha_" + appWidgetId, selectedAlpha);
                editor.putInt("widget_text_color_" + appWidgetId, selectedTextColor);
                editor.apply();

                // Обновляем виджет
                AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
                ShiftWidgetProvider.updateAppWidget(this, appWidgetManager, appWidgetId);

                // Возвращаем RESULT_OK для системы
                Intent resultValue = new Intent();
                resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
                setResult(RESULT_OK, resultValue);
                finish();
            });
        }
    }
}

