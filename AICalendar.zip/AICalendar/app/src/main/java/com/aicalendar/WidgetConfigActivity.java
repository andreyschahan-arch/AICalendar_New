package com.aicalendar;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;

public class WidgetConfigActivity extends Activity {

    private int appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private int selectedAlpha = 180;
    private int selectedTextColor = Color.WHITE;
    private int selectedBgColor = Color.parseColor("#1E1E1E"); // По умолчанию тёмный фон

    private Button btnTextWhite;
    private Button btnTextDark;
    private Button btnBgDark;
    private Button btnBgLight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(0, 0);
        setContentView(R.layout.activity_widget_config);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {
            appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }

        SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        selectedAlpha = prefs.getInt("widget_alpha_" + appWidgetId, 180);
        selectedTextColor = prefs.getInt("widget_text_color_" + appWidgetId, Color.WHITE);
        selectedBgColor = prefs.getInt("widget_bg_color_" + appWidgetId, Color.parseColor("#1E1E1E"));

        SeekBar sbAlpha = findViewById(R.id.sb_widget_alpha);
        btnTextWhite = findViewById(R.id.btn_text_white);
        btnTextDark = findViewById(R.id.btn_text_dark);
        btnBgDark = findViewById(R.id.btn_bg_dark);
        btnBgLight = findViewById(R.id.btn_bg_light);
        Button btnApply = findViewById(R.id.btn_apply_config);
        View bgOutside = findViewById(R.id.bg_touch_outside);

        if (sbAlpha != null) {
            sbAlpha.setMax(255);
            sbAlpha.setProgress(selectedAlpha);
            sbAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
					@Override
					public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
						selectedAlpha = progress;
					}
					@Override public void onStartTrackingTouch(SeekBar seekBar) {}
					@Override public void onStopTrackingTouch(SeekBar seekBar) {}
				});
        }

        updateSelectionUI();

        // Обработка кнопок ЦВЕТА ТЕКСТА
        if (btnTextWhite != null) {
            btnTextWhite.setOnClickListener(v -> {
                selectedTextColor = Color.WHITE;
                updateSelectionUI();
            });
        }

        if (btnTextDark != null) {
            btnTextDark.setOnClickListener(v -> {
                selectedTextColor = Color.BLACK;
                updateSelectionUI();
            });
        }

        // Обработка кнопок ЦВЕТА ФОНА
        if (btnBgDark != null) {
            btnBgDark.setOnClickListener(v -> {
                selectedBgColor = Color.parseColor("#1E1E1E");
                updateSelectionUI();
            });
        }

        if (btnBgLight != null) {
            btnBgLight.setOnClickListener(v -> {
                selectedBgColor = Color.parseColor("#E0E0E0");
                updateSelectionUI();
            });
        }

        if (bgOutside != null) {
            bgOutside.setOnClickListener(v -> finish());
        }

        if (btnApply != null) {
            btnApply.setOnClickListener(v -> {
                SharedPreferences.Editor editor = prefs.edit();
                editor.putInt("widget_alpha_" + appWidgetId, selectedAlpha);
                editor.putInt("widget_text_color_" + appWidgetId, selectedTextColor);
                editor.putInt("widget_bg_color_" + appWidgetId, selectedBgColor);
                editor.apply();

                AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
                ShiftWidgetProvider.updateAppWidget(this, appWidgetManager, appWidgetId);

                Intent updateIntent = new Intent(this, ShiftWidgetProvider.class);
                updateIntent.setAction(ShiftWidgetProvider.ACTION_WIDGET_UPDATE);
                sendBroadcast(updateIntent);

                Intent resultValue = new Intent();
                resultValue.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
                setResult(RESULT_OK, resultValue);
                finish();
            });
        }
    }

    private void updateSelectionUI() {
        // Подсветка кнопок ЦВЕТА ТЕКСТА
        if (btnTextWhite != null && btnTextDark != null) {
            if (selectedTextColor == Color.WHITE) {
                btnTextWhite.setAlpha(1.0f);
                btnTextDark.setAlpha(0.4f);
            } else {
                btnTextWhite.setAlpha(0.4f);
                btnTextDark.setAlpha(1.0f);
            }
        }

        // Подсветка кнопок ЦВЕТА ФОНА
        if (btnBgDark != null && btnBgLight != null) {
            if (selectedBgColor == Color.parseColor("#1E1E1E")) {
                btnBgDark.setAlpha(1.0f);
                btnBgLight.setAlpha(0.4f);
            } else {
                btnBgDark.setAlpha(0.4f);
                btnBgLight.setAlpha(1.0f);
            }
        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }
}

