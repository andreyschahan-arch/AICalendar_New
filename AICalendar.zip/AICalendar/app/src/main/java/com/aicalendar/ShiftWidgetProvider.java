package com.aicalendar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.text.TextUtils;
import android.widget.RemoteViews;

import java.util.Calendar;

public class ShiftWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_WIDGET_UPDATE = "com.aicalendar.ACTION_WIDGET_UPDATE";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        MainActivity.recalculateAndScheduleAlarms(context);
        updateAllWidgets(context);
        scheduleNextMidnightUpdate(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent.getAction();

        if (ACTION_WIDGET_UPDATE.equals(action) 
            || Intent.ACTION_DATE_CHANGED.equals(action) 
            || Intent.ACTION_TIME_CHANGED.equals(action)
            || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
            || Intent.ACTION_BOOT_COMPLETED.equals(action)) {

            MainActivity.recalculateAndScheduleAlarms(context);
            updateAllWidgets(context);
            scheduleNextMidnightUpdate(context);
        }
    }

    public static void updateAllWidgets(Context context) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
        ComponentName thisWidget = new ComponentName(context, ShiftWidgetProvider.class);
        int[] appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
        for (int id : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, id);
        }
    }

    private static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        try {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);
            SharedPreferences prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);

            // 1. Название текущей смены
            String todayShift = prefs.getString("today_shift_name", "Выходной");
            if (TextUtils.isEmpty(todayShift)) {
                views.setTextViewText(R.id.tv_widget_shift_name, "Сегодня: Выходной");
            } else {
                views.setTextViewText(R.id.tv_widget_shift_name, "Сегодня: " + todayShift);
            }

            // 2. Ближайший будильник
            long nextAlarmMs = prefs.getLong("next_alarm_time_ms", 0);
            String alarmLabel = prefs.getString("next_alarm_label", "Будильник");

            long now = System.currentTimeMillis();
            if (nextAlarmMs > now) {
                long diffMs = nextAlarmMs - now;
                long hours = diffMs / (1000 * 60 * 60);
                long minutes = (diffMs / (1000 * 60)) % 60;
                String timeText = hours > 0 ? hours + "ч " + minutes + "м" : minutes + "м";
                views.setTextViewText(R.id.tv_widget_next_alarm, alarmLabel + " через " + timeText);
            } else {
                views.setTextViewText(R.id.tv_widget_next_alarm, "Будильники отключены");
            }

            // 3. Массивы ID кубиков дней и заголовков
            String[] daysOfWeekStr = new String[]{"Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"};

            int[] bgIds = new int[]{
                R.id.widget_day0_bg, R.id.widget_day1_bg, R.id.widget_day2_bg, R.id.widget_day3_bg, R.id.widget_day4_bg
            };
            int[] titleIds = new int[]{
                R.id.widget_day0_title, R.id.widget_day1_title, R.id.widget_day2_title, R.id.widget_day3_title, R.id.widget_day4_title
            };
            int[] numIds = new int[]{
                R.id.widget_day0_num, R.id.widget_day1_num, R.id.widget_day2_num, R.id.widget_day3_num, R.id.widget_day4_num
            };

            // 4. Отрисовка 5 кубиков
            for (int i = 0; i < 5; i++) {
                Calendar cardCal = Calendar.getInstance();
                cardCal.add(Calendar.DAY_OF_MONTH, i - 2);

                int dayNum = cardCal.get(Calendar.DAY_OF_MONTH);
                int dayOfWeekIdx = cardCal.get(Calendar.DAY_OF_WEEK) - 1;

                views.setTextViewText(numIds[i], String.valueOf(dayNum));
                views.setTextViewText(titleIds[i], daysOfWeekStr[dayOfWeekIdx]);

                // Подтягиваем сохраненный цвет смены для кубика i (рассчитанный в MainActivity)
                int shiftColor = prefs.getInt("widget_color_" + i, Color.parseColor("#4CAF50"));

                // Раскрашиваем текст дня или границы под цвет смены
                views.setTextColor(titleIds[i], shiftColor);
            }

            // Flags для PendingIntent
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }

            // 5. Клик по виджету -> Открытие MainActivity
            Intent openAppIntent = new Intent(context, MainActivity.class);
            openAppIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent mainPendingIntent = PendingIntent.getActivity(context, appWidgetId, openAppIntent, flags);
            views.setOnClickPendingIntent(R.id.widget_root, mainPendingIntent);

            // 6. Клик по 2 полоскам -> Вызов экрана настроек виджета
            Intent configIntent = new Intent(context, WidgetConfigActivity.class);
            configIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            configIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent configPendingIntent = PendingIntent.getActivity(context, appWidgetId + 2000, configIntent, flags);
            views.setOnClickPendingIntent(R.id.btn_widget_settings, configPendingIntent);

            appWidgetManager.updateAppWidget(appWidgetId, views);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void scheduleNextMidnightUpdate(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Calendar midnight = Calendar.getInstance();
        midnight.add(Calendar.DAY_OF_MONTH, 1);
        midnight.set(Calendar.HOUR_OF_DAY, 0);
        midnight.set(Calendar.MINUTE, 0);
        midnight.set(Calendar.SECOND, 1);

        Intent intent = new Intent(context, ShiftWidgetProvider.class);
        intent.setAction(ACTION_WIDGET_UPDATE);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 1001, intent, flags);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, midnight.getTimeInMillis(), pendingIntent);
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, midnight.getTimeInMillis(), pendingIntent);
        }
    }
}

