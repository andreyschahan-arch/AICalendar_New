package com.aicalendar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.text.TextUtils;
import android.widget.RemoteViews;

import java.util.Calendar;

public class ShiftWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_WIDGET_UPDATE = "com.aicalendar.ACTION_WIDGET_UPDATE";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        MainActivity.recalculateAndScheduleAlarms(context);
        updateAllWidgets(context);
        scheduleNextMidnightUpdate(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent.getAction();

        if (ACTION_WIDGET_UPDATE.equals(action) 
            || Intent.ACTION_DATE_CHANGED.equals(action) 
            || Intent.ACTION_TIME_CHANGED.equals(action)
            || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
            || Intent.ACTION_BOOT_COMPLETED.equals(action)) {

            MainActivity.recalculateAndScheduleAlarms(context);
            updateAllWidgets(context);
            scheduleNextMidnightUpdate(context);
        }
    }

    public static void updateAllWidgets(Context context) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
        ComponentName thisWidget = new ComponentName(context, ShiftWidgetProvider.class);
        int[] appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
        for (int id : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, id);
        }
    }

    private static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        try {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);
            SharedPreferences prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);

            // 1. Отображение названия текущей смены
            String todayShift = prefs.getString("today_shift_name", "Выходной");
            if (TextUtils.isEmpty(todayShift)) {
                todayShift = "Выходной";
            }
            setSafeText(views, "tv_widget_shift_name", "Сегодня: " + todayShift);
            setSafeText(views, "widget_shift_name", todayShift);

            // 2. Ближайший будильник
            long nextAlarmMs = prefs.getLong("next_alarm_time_ms", 0);
            String alarmLabel = prefs.getString("next_alarm_label", "Будильник");

            long now = System.currentTimeMillis();
            String alarmText;
            if (nextAlarmMs > now) {
                long diffMs = nextAlarmMs - now;
                long hours = diffMs / (1000 * 60 * 60);
                long minutes = (diffMs / (1000 * 60)) % 60;
                alarmText = hours > 0 ? "через " + hours + "ч " + minutes + "м" : "через " + minutes + "м";
            } else {
                boolean isAlarmEnabled = prefs.getBoolean("alarm_enabled", true);
                alarmText = isAlarmEnabled ? "включен" : "отключен";
            }

            setSafeText(views, "tv_widget_next_alarm", alarmLabel + " " + alarmText);
            setSafeText(views, "widget_alarm_title", "⏰ " + alarmLabel);
            setSafeText(views, "widget_alarm_time", alarmText);

            // 3. Отображение 5 карточек дней
            String[] daysOfWeekStr = new String[]{"Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"};

            for (int i = 0; i < 5; i++) {
                Calendar cardCal = Calendar.getInstance();
                cardCal.add(Calendar.DAY_OF_MONTH, i - 2);

                int dayNum = cardCal.get(Calendar.DAY_OF_MONTH);
                int dayOfWeekIdx = cardCal.get(Calendar.DAY_OF_WEEK) - 1;

                // Поддержка двух вариантов разметки (day_X_num и widget_dayX_num)
                setSafeText(views, "day_" + (i + 1) + "_num", String.valueOf(dayNum));
                setSafeText(views, "widget_day" + i + "_num", String.valueOf(dayNum));

                if (i != 2) {
                    setSafeText(views, "day_" + (i + 1) + "_sub", daysOfWeekStr[dayOfWeekIdx]);
                }
                setSafeText(views, "widget_day" + i + "_title", daysOfWeekStr[dayOfWeekIdx]);

                // Цвет смены из календаря
                int shiftColor = prefs.getInt("widget_color_" + i, Color.WHITE);

                // Окраска контура рамок/фона
                setSafeColorFilter(context, views, "day_" + (i + 1) + "_bg", shiftColor);
                setSafeColorFilter(context, views, "widget_day" + i + "_bg", shiftColor);
            }

            // 4. Настройка клика по виджету
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }

            Intent openAppIntent = new Intent(context, MainActivity.class);
            openAppIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent mainPendingIntent = PendingIntent.getActivity(context, appWidgetId, openAppIntent, flags);

            setSafeOnClick(context, views, "widget_root", mainPendingIntent);
            setSafeOnClick(context, views, "widget_main_layout", mainPendingIntent);
            setSafeOnClick(context, views, "widget_shift_name", mainPendingIntent);

            appWidgetManager.updateAppWidget(appWidgetId, views);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Безопасная установка текста через рефлексию ID
    private static void setSafeText(RemoteViews views, String idName, String text) {
        int id = getResId(idName, "id");
        if (id != 0) {
            views.setTextViewText(id, text);
        }
    }

    // Безопасное наложение цветового фильтра на ImageView
    private static void setSafeColorFilter(Context context, RemoteViews views, String idName, int color) {
        int id = getResId(idName, "id");
        if (id != 0) {
            views.setInt(id, "setColorFilter", color);
        }
    }

    // Безопасная установка клика
    private static void setSafeOnClick(Context context, RemoteViews views, String idName, PendingIntent pendingIntent) {
        int id = getResId(idName, "id");
        if (id != 0) {
            views.setOnClickPendingIntent(id, pendingIntent);
        }
    }

    // Вспомогательный метод для динамического поиска ID ресурса без ошибок компиляции
    private static int getResId(String resName, String className) {
        try {
            return com.aicalendar.R.id.class.getField(resName).getInt(null);
        } catch (Exception e) {
            return 0;
        }
    }

    private static void scheduleNextMidnightUpdate(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Calendar midnight = Calendar.getInstance();
        midnight.add(Calendar.DAY_OF_MONTH, 1);
        midnight.set(Calendar.HOUR_OF_DAY, 0);
        midnight.set(Calendar.MINUTE, 0);
        midnight.set(Calendar.SECOND, 1);

        Intent intent = new Intent(context, ShiftWidgetProvider.class);
        intent.setAction(ACTION_WIDGET_UPDATE);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 1001, intent, flags);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, midnight.getTimeInMillis(), pendingIntent);
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, midnight.getTimeInMillis(), pendingIntent);
        }
    }
}

