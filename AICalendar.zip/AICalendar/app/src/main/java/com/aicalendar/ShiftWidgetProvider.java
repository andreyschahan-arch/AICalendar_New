package com.aicalendar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.text.TextUtils;
import android.widget.RemoteViews;

import java.util.Calendar;

public class ShiftWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_WIDGET_UPDATE = "com.aicalendar.ACTION_WIDGET_UPDATE";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        MainActivity.recalculateAndScheduleAlarms(context);
        updateAllWidgets(context);
        scheduleNextMidnightUpdate(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent.getAction();

        if (ACTION_WIDGET_UPDATE.equals(action) 
            || Intent.ACTION_DATE_CHANGED.equals(action) 
            || Intent.ACTION_TIME_CHANGED.equals(action)
            || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
            || Intent.ACTION_BOOT_COMPLETED.equals(action)) {

            MainActivity.recalculateAndScheduleAlarms(context);
            updateAllWidgets(context);
            scheduleNextMidnightUpdate(context);
        }
    }

    public static void updateAllWidgets(Context context) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
        ComponentName thisWidget = new ComponentName(context, ShiftWidgetProvider.class);
        int[] appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
        for (int id : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, id);
        }
    }

    private static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        try {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);
            SharedPreferences prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);

            // 1. Название смены
            String todayShift = prefs.getString("today_shift_name", "");
            if (TextUtils.isEmpty(todayShift)) {
                todayShift = prefs.getString("day_0_name", "2 РАБОЧИЙ");
            }
            int shiftNameResId = getResId(context, "widget_shift_name");
            if (shiftNameResId != 0) {
                views.setTextViewText(shiftNameResId, todayShift);
            }

            // 2. Ближайший будильник
            long nextAlarmMs = prefs.getLong("next_alarm_time_ms", 0);
            String alarmLabel = prefs.getString("next_alarm_label", "Подъем!");
            if (TextUtils.isEmpty(alarmLabel)) {
                alarmLabel = "Подъем!";
            }

            int alarmTitleResId = getResId(context, "widget_alarm_title");
            if (alarmTitleResId != 0) {
                views.setTextViewText(alarmTitleResId, "⏰ " + alarmLabel);
            }

            int alarmTimeResId = getResId(context, "widget_alarm_time");
            if (alarmTimeResId != 0) {
                long now = System.currentTimeMillis();
                if (nextAlarmMs > now) {
                    long diffMs = nextAlarmMs - now;
                    long hours = diffMs / (1000 * 60 * 60);
                    long minutes = (diffMs / (1000 * 60)) % 60;
                    views.setTextViewText(alarmTimeResId, hours > 0 ? "через " + hours + "ч " + minutes + "м" : "через " + minutes + "м");
                } else {
                    boolean isAlarmEnabled = prefs.getBoolean("alarm_enabled", true);
                    views.setTextViewText(alarmTimeResId, isAlarmEnabled ? "включен" : "отключен");
                }
            }

            // 3. Динамическая подгрузка 5 дней
            String[] daysOfWeekStr = new String[]{"Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"};

            for (int i = 0; i < 5; i++) {
                int numResId = getResId(context, "day_" + (i + 1) + "_num");
                int subResId = getResId(context, "day_" + (i + 1) + "_sub");
                int bgResId = getResId(context, "day_" + (i + 1) + "_bg");

                Calendar cardCal = Calendar.getInstance();
                cardCal.add(Calendar.DAY_OF_MONTH, i - 2);

                int dayNum = cardCal.get(Calendar.DAY_OF_MONTH);
                int dayOfWeekIdx = cardCal.get(Calendar.DAY_OF_WEEK) - 1;

                if (numResId != 0) {
                    views.setTextViewText(numResId, String.valueOf(dayNum));
                }

                if (subResId != 0 && i != 2) {
                    views.setTextViewText(subResId, daysOfWeekStr[dayOfWeekIdx]);
                }

                if (bgResId != 0) {
                    int color = prefs.getInt("widget_color_" + i, Color.WHITE);
                    views.setInt(bgResId, "setColorFilter", color);
                }
            }

            // 4. Запуск приложения по нажатию на виджет
            Intent openAppIntent = new Intent(context, MainActivity.class);
            openAppIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }

            PendingIntent pendingIntent = PendingIntent.getActivity(context, appWidgetId, openAppIntent, flags);

            int mainLayoutResId = getResId(context, "widget_main_layout");
            if (mainLayoutResId != 0) {
                views.setOnClickPendingIntent(mainLayoutResId, pendingIntent);
            }

            appWidgetManager.updateAppWidget(appWidgetId, views);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static int getResId(Context context, String name) {
        return context.getResources().getIdentifier(name, "id", context.getPackageName());
    }

    private static void scheduleNextMidnightUpdate(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Calendar midnight = Calendar.getInstance();
        midnight.add(Calendar.DAY_OF_MONTH, 1);
        midnight.set(Calendar.HOUR_OF_DAY, 0);
        midnight.set(Calendar.MINUTE, 0);
        midnight.set(Calendar.SECOND, 1);

        Intent intent = new Intent(context, ShiftWidgetProvider.class);
        intent.setAction(ACTION_WIDGET_UPDATE);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 1001, intent, flags);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, midnight.getTimeInMillis(), pendingIntent);
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, midnight.getTimeInMillis(), pendingIntent);
        }
    }
}

