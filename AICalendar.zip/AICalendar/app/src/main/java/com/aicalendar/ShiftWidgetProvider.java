package com.aicalendar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.widget.RemoteViews;

import java.util.Calendar;

public class ShiftWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_WIDGET_UPDATE = "com.aicalendar.ACTION_WIDGET_UPDATE";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
        scheduleNextMidnightUpdate(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);

        if (ACTION_WIDGET_UPDATE.equals(intent.getAction()) ||
            Intent.ACTION_DATE_CHANGED.equals(intent.getAction()) ||
            Intent.ACTION_TIMEZONE_CHANGED.equals(intent.getAction()) ||
            Intent.ACTION_TIME_CHANGED.equals(intent.getAction())) {

            updateAllWidgets(context);
            scheduleNextMidnightUpdate(context);
        }
    }

    public static void updateAllWidgets(Context context) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
        ComponentName thisWidget = new ComponentName(context, ShiftWidgetProvider.class);
        int[] appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);

        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    public static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);

        // 1. Читаем настройки из SharedPreferences "app_prefs"
        SharedPreferences prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        int bgStyle = prefs.getInt("widget_bg_style_" + appWidgetId, 1);
        int textColor = prefs.getInt("widget_text_color_" + appWidgetId, Color.WHITE);

        // 2. Устанавливаем соответствующий drawable-ресурс с сохранением скруглений
        int bgResId;
        switch (bgStyle) {
            case 2:
                bgResId = R.drawable.wbg_2;
                break;
            case 3:
                bgResId = R.drawable.wbg_3;
                break;
            case 4:
                bgResId = R.drawable.wbg_4;
                break;
            case 5:
                bgResId = R.drawable.wbg_5;
                break;
            case 1:
            default:
                bgResId = R.drawable.wbg_1;
                break;
        }
        views.setInt(R.id.widget_main_layout, "setBackgroundResource", bgResId);

        // 3. Текст (смена и будильник)
        String shiftName = prefs.getString("widget_shift_name", "2 РАБОЧИЙ");
        views.setTextViewText(R.id.widget_shift_name, shiftName);
        views.setTextColor(R.id.widget_shift_name, textColor);

        String alarmTime = prefs.getString("widget_alarm_time", "Нет будильников");
        views.setTextViewText(R.id.widget_alarm_time, alarmTime);
        views.setTextColor(R.id.widget_alarm_time, textColor);

        // 4. Дни и даты
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, -2);

        int[] dayNumIds = new int[]{
            R.id.day_1_num, R.id.day_2_num, R.id.day_3_num, R.id.day_4_num, R.id.day_5_num
        };

        int[] dayBgIds = new int[]{
            R.id.day_1_bg, R.id.day_2_bg, R.id.day_3_bg, R.id.day_4_bg, R.id.day_5_bg
        };

        for (int i = 0; i < 5; i++) {
            int dayNumber = cal.get(Calendar.DAY_OF_MONTH);
            views.setTextViewText(dayNumIds[i], String.valueOf(dayNumber));
            views.setTextColor(dayNumIds[i], textColor);

            if (i == 2) {
                views.setInt(dayBgIds[i], "setBackgroundResource", R.drawable.today_bg);
            } else {
                views.setInt(dayBgIds[i], "setBackgroundResource", R.drawable.day_bg);
            }

            cal.add(Calendar.DAY_OF_MONTH, 1);
        }

        // 5. Нажатия на виджет и иконку настроек
        Intent openAppIntent = new Intent(context, MainActivity.class);
        openAppIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openAppPendingIntent = PendingIntent.getActivity(
			context, 0, openAppIntent,
			PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
        );
        views.setOnClickPendingIntent(R.id.widget_main_layout, openAppPendingIntent);

        Intent openConfigIntent = new Intent(context, WidgetConfigActivity.class);
        openConfigIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        openConfigIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent openConfigPendingIntent = PendingIntent.getActivity(
			context, appWidgetId, openConfigIntent,
			PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
        );
        views.setOnClickPendingIntent(R.id.widget_btn_settings, openConfigPendingIntent);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    private static void scheduleNextMidnightUpdate(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Calendar midnight = Calendar.getInstance();
        midnight.add(Calendar.DAY_OF_MONTH, 1);
        midnight.set(Calendar.HOUR_OF_DAY, 0);
        midnight.set(Calendar.MINUTE, 0);
        midnight.set(Calendar.SECOND, 1);

        Intent intent = new Intent(context, ShiftWidgetProvider.class);
        intent.setAction(ACTION_WIDGET_UPDATE);

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent, flags);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, midnight.getTimeInMillis(), pendingIntent);
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, midnight.getTimeInMillis(), pendingIntent);
        }
    }
}

