package com.aicalendar;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.widget.RemoteViews;
import java.util.Calendar;

public class ShiftWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_WIDGET_UPDATE = "com.aicalendar.ACTION_WIDGET_UPDATE";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateAllWidgets(context);
        scheduleNextMidnightUpdate(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent.getAction();

        if (ACTION_WIDGET_UPDATE.equals(action) 
            || Intent.ACTION_DATE_CHANGED.equals(action) 
            || Intent.ACTION_TIME_CHANGED.equals(action)
            || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
            || Intent.ACTION_BOOT_COMPLETED.equals(action)) {

            updateAllWidgets(context);
            scheduleNextMidnightUpdate(context);
        }
    }

    public static void updateAllWidgets(Context context) {
        try {
            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context);
            ComponentName thisWidget = new ComponentName(context, ShiftWidgetProvider.class);
            int[] appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
            if (appWidgetIds != null) {
                for (int id : appWidgetIds) {
                    updateAppWidget(context, appWidgetManager, id);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, int appWidgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);

        SharedPreferences prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE);

        // --- 1. ПРИМЕНЕНИЕ ВЫБРАННОГО СТИЛЯ, ПРОЗРАЧНОСТИ И ЦВЕТА ТЕКСТА ---
        int styleIndex = prefs.getInt("widget_bg_style_" + appWidgetId, 1);
        int alpha = prefs.getInt("widget_alpha_" + appWidgetId, 255);
        int textColor = prefs.getInt("widget_text_color_" + appWidgetId, Color.WHITE);

        int bgDrawableRes;
        switch (styleIndex) {
            case 2:
                bgDrawableRes = R.drawable.wbg_2;
                break;
            case 3:
                bgDrawableRes = R.drawable.wbg_3;
                break;
            case 4:
                bgDrawableRes = R.drawable.wbg_4;
                break;
            case 5:
                bgDrawableRes = R.drawable.wbg_5;
                break;
            case 1:
            default:
                bgDrawableRes = R.drawable.wbg_1;
                break;
        }

        // Устанавливаем градиент и прозрачность главного контейнера
        views.setInt(R.id.widget_main_layout, "setBackgroundResource", bgDrawableRes);
        views.setInt(R.id.widget_main_layout, "setImageAlpha", alpha);

        // --- 2. ЦВЕТ ТЕКСТА И ИКОНОК ---
        views.setTextColor(R.id.widget_shift_name, textColor);
        views.setTextColor(R.id.widget_alarm_time, textColor);
        views.setInt(R.id.widget_btn_settings, "setColorFilter", textColor);

        // --- 3. ДАННЫЕ О СМЕНЕ И БУДИЛЬНИКЕ ---
        String todayShiftName = prefs.getString("today_shift_name", "Выходной");
        long nextAlarmTimeMs = prefs.getLong("next_alarm_time_ms", 0);
        String nextAlarmLabel = prefs.getString("next_alarm_label", "");

        views.setTextViewText(R.id.widget_shift_name, todayShiftName);

        if (nextAlarmTimeMs > System.currentTimeMillis()) {
            Calendar alarmCal = Calendar.getInstance();
            alarmCal.setTimeInMillis(nextAlarmTimeMs);
            String timeStr = String.format(java.util.Locale.US, "%02d:%02d", 
                                           alarmCal.get(Calendar.HOUR_OF_DAY), alarmCal.get(Calendar.MINUTE));

            String labelText = nextAlarmLabel.isEmpty() ? timeStr : timeStr + " (" + nextAlarmLabel + ")";
            views.setTextViewText(R.id.widget_alarm_time, labelText);
            views.setViewVisibility(R.id.widget_alarm_time, View.VISIBLE);
        } else {
            views.setTextViewText(R.id.widget_alarm_time, "Нет будильников");
            views.setViewVisibility(R.id.widget_alarm_time, View.VISIBLE);
        }

        // --- 4. ДНИ И АКТУАЛЬНЫЕ ДАТЫ ---
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, -2);

        int[] dayNumIds = new int[]{
            R.id.day_1_num, R.id.day_2_num, R.id.day_3_num, R.id.day_4_num, R.id.day_5_num
        };

        int[] dayBgIds = new int[]{
            R.id.day_1_bg, R.id.day_2_bg, R.id.day_3_bg, R.id.day_4_bg, R.id.day_5_bg
        };

        for (int i = 0; i < 5; i++) {
            int dayNumber = cal.get(Calendar.DAY_OF_MONTH);
            views.setTextViewText(dayNumIds[i], String.valueOf(dayNumber));
            views.setTextColor(dayNumIds[i], textColor);

            int color = prefs.getInt("widget_color_" + i, 0xFF4CAF50);
            views.setInt(dayBgIds[i], "setBackgroundColor", color);

            cal.add(Calendar.DAY_OF_MONTH, 1);
        }

        // --- 5. ОБРАБОТКА НАЖАТИЙ ---
        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? 
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE : 
            PendingIntent.FLAG_UPDATE_CURRENT;

        Intent openAppIntent = new Intent(context, MainActivity.class);
        openAppIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openAppPendingIntent = PendingIntent.getActivity(context, 101, openAppIntent, flags);
        views.setOnClickPendingIntent(R.id.widget_main_layout, openAppPendingIntent);

        Intent openConfigIntent = new Intent(context, WidgetConfigActivity.class);
        openConfigIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        openConfigIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent openConfigPendingIntent = PendingIntent.getActivity(context, 102, openConfigIntent, flags);

        views.setOnClickPendingIntent(R.id.widget_btn_settings, openConfigPendingIntent);

        appWidgetManager.updateAppWidget(appWidgetId, views);
    }

    private static void scheduleNextMidnightUpdate(Context context) {
        try {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarmManager == null) return;

            Calendar midnight = Calendar.getInstance();
            midnight.add(Calendar.DAY_OF_MONTH, 1);
            midnight.set(Calendar.HOUR_OF_DAY, 0);
            midnight.set(Calendar.MINUTE, 0);
            midnight.set(Calendar.SECOND, 1);

            Intent intent = new Intent(context, ShiftWidgetProvider.class);
            intent.setAction(ACTION_WIDGET_UPDATE);

            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= PendingIntent.FLAG_IMMUTABLE;
            }

            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 1001, intent, flags);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, midnight.getTimeInMillis(), pendingIntent);
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, midnight.getTimeInMillis(), pendingIntent);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

